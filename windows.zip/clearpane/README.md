# Clearpane Glazing & Window Repair – website prototype

Frontend-only demo site for a fictional UK glazing business (owner Stuart, Stockport).
Next.js (App Router, static export), React, TypeScript (strict), Tailwind CSS v4, Zod, lucide-react.

**Demo only.** The business, reviews, prices, phone number and photos are placeholders. The quote form sends and stores nothing.
Replace all of them (and remove `robots: { index: false }` in `src/app/layout.tsx`) before showing a real prospect.

## Run

```bash
npm install
npm run dev          # http://localhost:3000
npm run build        # static site in ./out (deploy anywhere: Netlify, Vercel, GitHub Pages, ...)
```

## Content

Everything editable lives in `src/site.config.ts` (validated at build time by `src/lib/config-schema.ts`).
Images are listed in `src/data/images.ts`; files are in `public/images/`.

- One call-to-action label (`ctaLabel`) opens the quote drawer. Shown in the hero, the bottom section and a fixed bar on mobile.
- The WhatsApp button is laptop-only; the phone icon sits in the mobile header and the mobile fixed bar.
- Add `?simulate=error` to the URL to see the quote form's error state.

## Single-file HTML (double-click to open)

```bash
npm run build:portable
```

Writes `portable/clearpane-site.html` (the whole site in one file) and `portable/clearpane-preview.html`
(laptop / mobile / side-by-side viewer). Note this overwrites `./out` with a build that loads the quote drawer eagerly.
Run `npm run build` again afterwards if you want the normal static export.

## Checks

```bash
npm run typecheck
npm run lint
npm run build
python3 scripts/e2e-check.py        # needs: pip install playwright && playwright install chromium
python3 scripts/responsive-check.py
```
