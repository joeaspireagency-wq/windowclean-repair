/**
 * Builds ONE self-contained HTML file (CSS, JS, fonts and images inlined) from
 * the static export in ./out, so the site opens by double-click, from disk or
 * email, with no server. Also writes a laptop/mobile preview wrapper.
 *
 * Run via: npm run build:portable
 */
import { readFileSync, writeFileSync, mkdirSync, existsSync, readdirSync } from "node:fs";
import { join, dirname } from "node:path";
import { fileURLToPath } from "node:url";

const root = join(dirname(fileURLToPath(import.meta.url)), "..");
const out = join(root, "out");
const dist = join(root, "portable");
mkdirSync(dist, { recursive: true });

let html = readFileSync(join(out, "index.html"), "utf8");
const mime = { svg: "image/svg+xml", woff2: "font/woff2", css: "text/css", png: "image/png", jpg: "image/jpeg", webp: "image/webp", avif: "image/avif" };
const dataUri = (rel) => {
  const file = join(out, rel.replace(/^\//, "").split("?")[0]);
  if (!existsSync(file)) return null;
  const ext = file.split(".").pop();
  return `data:${mime[ext] ?? "application/octet-stream"};base64,${readFileSync(file).toString("base64")}`;
};

// 1. Drop font preload hints and the stylesheet links (fonts + CSS are inlined below).
html = html.replace(/<link[^>]+rel="preload"[^>]+as="font"[^>]*>/g, "");

html = html.replace(/<link[^>]+rel="preload"[^>]+as="script"[^>]*>/g, "");
// The stylesheet is already inlined (experimental.inlineCss); neutralise any leftover reference to the .css file.
html = html.replace(/\/_next\/static\/chunks\/[A-Za-z0-9_\-]+\.css/g, "data:text/css;base64,");

// 3. Inline every script (order preserved). Escape closing tags inside the code.
// Turbopack chunks identify themselves via document.currentScript.getAttribute("src"),
// which is empty for inline scripts. Give each chunk a shim that returns its original path.
const chunkCode = (src) =>
  readFileSync(join(out, src.replace(/^\//, "")), "utf8")
    .split("document.currentScript")
    .join(`({getAttribute:function(){return ${JSON.stringify(src)}}})`)
    // Embedded viewers load the page from about:srcdoc / blob: URLs, which cannot be used as a URL base.
    // Route the router's location lookups through safe values defined in the bootstrap script.
    .split("window.location.href").join("window.__cpHref")
    .split("window.location.origin").join("window.__cpOrigin")
    .split("location.href").join("window.__cpHref")
    .split("location.origin").join("window.__cpOrigin")
    .replace(/<\/script/gi, "<\\/script");
const inlined = new Set();
html = html.replace(/<script\b([^>]*?)\ssrc="(\/_next\/[^"]+\.js)"([^>]*)><\/script>/g, (m, a, src, b) => {
  if (!existsSync(join(out, src.replace(/^\//, "")))) return m;
  inlined.add(src);
  const attrs = `${a}${b}`.replace(/\sasync(="")?/g, "").replace(/\sdefer(="")?/g, "").trim();
  return `<script${attrs ? " " + attrs : ""}>window.__cpDone[${JSON.stringify(src)}]=1;${chunkCode(src)}</script>`;
});
// Chunks that the runtime may request later (lazy chunks) plus React's own <script src> resources:
// on file:// "/_next/..." cannot resolve, so redirect every script src to a blob made from the embedded code.
const lazy = {};
for (const f of readdirSync(join(out, "_next/static/chunks"))) {
  const src = `/_next/static/chunks/${f}`;
  if (f.endsWith(".js") && !inlined.has(src)) lazy[src] = chunkCode(src);
}
const bootstrap = `<script>(function(){var L=location,bad=/^(about|blob|data):$/.test(L.protocol);window.__cpHref=bad?"http://localhost/":L.href;window.__cpOrigin=bad?"http://localhost":L.origin;
["pushState","replaceState"].forEach(function(k){var o=history[k];history[k]=function(){try{return o.apply(this,arguments)}catch(e){}}});
var done=window.__cpDone={},lazy=${JSON.stringify(lazy).replace(/<\//g, "<\\/")};
function map(v){if(typeof v==="string"&&v.indexOf("/_next/")===0){var p=v.split("?")[0];var c=done[p]?"":(lazy[p]||"");return URL.createObjectURL(new Blob([c],{type:"text/javascript"}))}return v}
var d=Object.getOwnPropertyDescriptor(HTMLScriptElement.prototype,"src");
Object.defineProperty(HTMLScriptElement.prototype,"src",{configurable:true,get:function(){return d.get.call(this)},set:function(v){d.set.call(this,map(v))}});
var sa=Element.prototype.setAttribute;
Element.prototype.setAttribute=function(n,v){if(this.tagName==="SCRIPT"&&n==="src")v=map(v);return sa.call(this,n,v)};
})()</script>`;
html = html.replace(/<head>/, "<head>" + bootstrap);

// 4. Inline fonts + images everywhere. In the hydration payload, text ("T") rows carry a byte-length
// prefix, so lengths are recomputed after replacing; resource hints at server-root URLs are dropped.
const assetRe = /url\((["']?)(\/_next\/static\/media\/[^)"']+)\1\)|(\/images\/[A-Za-z0-9_\-/]+\.(?:svg|png|jpg|webp|avif))/g;
const inlineAssets = (text) =>
  text.replace(assetRe, (m, q, fontPath, imgPath) => {
    const uri = dataUri(fontPath ?? imgPath);
    if (!uri) return m;
    return fontPath ? `url(${uri})` : uri;
  });
const fixFlight = (flight) => {
  const buf = Buffer.from(flight, "utf8");
  const parts = [];
  let i = 0;
  while (i < buf.length) {
    const colon = buf.indexOf(0x3a, i);
    if (colon === -1) { parts.push(buf.subarray(i)); break; }
    const id = buf.subarray(i, colon).toString("utf8");
    if (/^[0-9a-f]*$/.test(id) && buf[colon + 1] === 0x54) {
      const comma = buf.indexOf(0x2c, colon);
      const len = parseInt(buf.subarray(colon + 2, comma).toString("utf8"), 16);
      const body = buf.subarray(comma + 1, comma + 1 + len);
      const text = inlineAssets(body.toString("utf8"));
      parts.push(Buffer.from(`${id}:T${Buffer.byteLength(text).toString(16)},${text}`, "utf8"));
      i = comma + 1 + len;
    } else {
      let nl = buf.indexOf(0x0a, i);
      nl = nl === -1 ? buf.length : nl + 1;
      const line = buf.subarray(i, nl).toString("utf8");
      parts.push(Buffer.from(/^:HL\["\/_next\//.test(line) ? "" : inlineAssets(line), "utf8"));
      i = nl;
    }
  }
  return Buffer.concat(parts).toString("utf8");
};
const LS0 = String.fromCharCode(0x2028), PS0 = String.fromCharCode(0x2029);
// A "T" row can straddle two push() calls, so rebuild the whole flight stream first, fix it as one piece,
// and emit it from the first push (the others become no-ops).
const pushRe = /self\.__next_f\.push\(\[1,("(?:[^"\\]|\\.)*")\]\)/g;
const pieces = [...html.matchAll(pushRe)].map((m) => JSON.parse(m[1]));
const fixedStream = fixFlight(pieces.join(""));
let first = true;
html = html.replace(pushRe, () => {
  if (!first) return "void 0";
  first = false;
  const ser = JSON.stringify(fixedStream)
    .replace(/<\//g, "<\\/").split(LS0).join("\\u2028").split(PS0).join("\\u2029");
  return `self.__next_f.push([1,${ser}])`;
});
html = inlineAssets(html);

// 5. Favicon.
html = html.replace(/href="\/icon\.svg[^"]*"/g, (m) => `href="${dataUri("/icon.svg")}"`);

// 6. Anything left that points at the server root would break on file://.
const leftovers = [...new Set(html.match(/(?:src|href)="\/(?:_next|images)\/[^"]*"/g) ?? [])];
if (leftovers.length) console.warn("Unresolved absolute asset URLs:", leftovers.slice(0, 5));

writeFileSync(join(dist, "clearpane-site.html"), html);
console.log(`portable/clearpane-site.html  ${(html.length / 1024).toFixed(0)} KB`);

/* ---------- laptop / mobile preview wrapper ---------- */
const wrapper = readFileSync(join(root, "scripts/preview-template.html"), "utf8");
const LS = String.fromCharCode(0x2028), PS = String.fromCharCode(0x2029);
const payload = JSON.stringify(html).replace(/<\//g, "<\\/").split(LS).join("\\u2028").split(PS).join("\\u2029");
writeFileSync(join(dist, "clearpane-preview.html"), wrapper.replace("/*__SITE_HTML__*/\"\"", () => payload));
console.log("portable/clearpane-preview.html (laptop + mobile switcher)");
