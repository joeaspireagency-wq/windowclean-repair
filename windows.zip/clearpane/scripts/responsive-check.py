"""
Dev-only responsive check (not shipped). Serves ./out, screenshots each width
and asserts there is no horizontal overflow.
Usage: npm run build && python3 scripts/responsive-check.py
Needs: pip install playwright && python3 -m playwright install chromium
"""
import http.server, socketserver, threading, os, sys, functools
from playwright.sync_api import sync_playwright

ROOT = os.path.join(os.path.dirname(__file__), "..", "out")
SHOTS = os.path.join(os.path.dirname(__file__), "..", "shots")
WIDTHS = [375, 390, 430, 768, 1024, 1440, 1920]
os.makedirs(SHOTS, exist_ok=True)

class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *args, **kwargs):
        pass

handler = functools.partial(Quiet, directory=ROOT)
httpd = socketserver.TCPServer(("127.0.0.1", 0), handler)
port = httpd.server_address[1]
threading.Thread(target=httpd.serve_forever, daemon=True).start()

failures = []
with sync_playwright() as p:
    browser = p.chromium.launch()
    for w in WIDTHS:
        page = browser.new_page(viewport={"width": w, "height": 900})
        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
        page.goto(f"http://127.0.0.1:{port}/", wait_until="networkidle")
        # scroll through the page so lazy images load and reveal-once effects fire
        h = page.evaluate("document.documentElement.scrollHeight")
        for y in range(0, h, 600):
            page.evaluate(f"window.scrollTo(0,{y})")
            page.wait_for_timeout(60)
        page.evaluate("window.scrollTo(0,0)")
        page.wait_for_timeout(1500)
        sw = page.evaluate("document.documentElement.scrollWidth")
        iw = page.evaluate("window.innerWidth")
        ok = sw <= iw
        print(f"{w:>5}px  scrollWidth={sw} innerWidth={iw}  {'OK' if ok else 'OVERFLOW'}  console_errors={len(errors)}")
        if not ok: failures.append(w)
        page.screenshot(path=os.path.join(SHOTS, f"full-{w}.png"), full_page=True)
        page.close()
    browser.close()
sys.exit(1 if failures else 0)
