"""
Dev-only interaction + compliance check (not shipped).
Usage: npm run build && python3 scripts/e2e-check.py
"""
import http.server, socketserver, threading, os, functools, sys, json
from playwright.sync_api import sync_playwright, expect

ROOT = os.path.join(os.path.dirname(__file__), "..", "out")
SHOTS = os.path.join(os.path.dirname(__file__), "..", "shots")

class Quiet(http.server.SimpleHTTPRequestHandler):
    def log_message(self, *a, **k): pass
httpd = socketserver.TCPServer(("127.0.0.1", 0), functools.partial(Quiet, directory=ROOT))
PORT = httpd.server_address[1]
threading.Thread(target=httpd.serve_forever, daemon=True).start()
BASE = f"http://127.0.0.1:{PORT}/"

results = []
def check(name, cond, extra=""):
    results.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name + (f"  [{extra}]" if extra else ""))

def open_page(browser, width=1440, height=900, url=BASE, **ctx):
    c = browser.new_context(viewport={"width": width, "height": height}, **ctx)
    pg = c.new_page()
    errs = []
    pg.on("pageerror", lambda e: errs.append(str(e)))
    pg.on("console", lambda m: errs.append(m.text) if m.type == "error" else None)
    pg.goto(url, wait_until="networkidle")
    return c, pg, errs

def dlg(pg): return pg.locator("dialog.drawer")
def step_text(pg): return pg.locator("dialog [role=progressbar]").get_attribute("aria-valuetext")

with sync_playwright() as p:
    browser = p.chromium.launch()

    # ---------- 1. full journey, desktop, emergency ----------
    c, pg, errs = open_page(browser)
    requests_after = []
    pg.locator("#hero .cta").click()
    check("hero CTA opens drawer", dlg(pg).is_visible())
    check("drawer opens at step 1", step_text(pg) == "Step 1 of 3")
    pg.click("dialog button:has-text('Next')")
    check("empty postcode shows error", pg.locator("#qf-postcode[aria-invalid=true]").count() == 1)
    check("focus moves to first error", pg.evaluate("document.activeElement && document.activeElement.id") == "qf-postcode")
    pg.fill("#qf-postcode", "NOTAPOSTCODE")
    pg.click("dialog button:has-text('Next')")
    check("bad postcode rejected", "UK postcode" in pg.locator("dialog").inner_text())
    pg.fill("#qf-postcode", "sk4 0ab")
    pg.click("dialog button:has-text('Next')")
    check("valid postcode -> step 2", step_text(pg) == "Step 2 of 3")
    pg.click("dialog button:has-text('Next')")
    check("step 2 requires problem + urgency", "closest to your problem" in pg.locator("dialog").inner_text() and "how urgent" in pg.locator("dialog").inner_text().lower())
    pg.locator("dialog label:has-text('Misted or foggy')").click()
    pg.locator("dialog label:has-text('Emergency today')").click()
    note = pg.locator("dialog [role=note]", has_text="999")
    check("999 note shown for Emergency today", note.count() == 1 and "within 30 minutes" in note.inner_text())
    pg.screenshot(path=os.path.join(SHOTS, "drawer-desktop-step2.png"))
    pg.click("dialog button:has-text('Next')")
    check("-> step 3", step_text(pg) == "Step 3 of 3")
    pg.click("dialog button[type=submit]")
    check("step 3 empty shows errors", pg.locator("#qf-name[aria-invalid=true]").count() == 1 and pg.locator("#qf-phone[aria-invalid=true]").count() == 1)
    pg.fill("#qf-name", "Sarah Jones")
    pg.fill("#qf-phone", "12345")
    pg.click("dialog button[type=submit]")
    check("bad phone rejected", "UK phone number" in pg.locator("dialog").inner_text())
    pg.fill("#qf-phone", "07700 900142")
    # photo is UI only
    pg.set_input_files("dialog input[type=file]", {"name": "crack.jpg", "mimeType": "image/jpeg", "buffer": b"x"})
    check("photo name shown (UI only)", "crack.jpg" in pg.locator("dialog").inner_text())
    pg.on("request", lambda r: requests_after.append(r.url))
    pg.screenshot(path=os.path.join(SHOTS, "drawer-desktop-step3.png"))
    pg.click("dialog button[type=submit]")
    pg.wait_for_selector("text=ring you within 30 minutes")
    txt = pg.locator("dialog").inner_text()
    check("emergency success copy", "Thanks Sarah, Stuart's team will ring you within 30 minutes (Mon-Sat, opening hours)." in txt)
    check("demo note removed from the drawer", "Demonstration only" not in txt)
    check("no network request on submit", len(requests_after) == 0, str(requests_after))
    store = pg.evaluate("({ls: localStorage.length, ss: sessionStorage.length, ck: document.cookie})")
    check("nothing stored (no localStorage/cookies)", store["ls"] == 0 and store["ss"] == 0 and store["ck"] == "", json.dumps(store))
    pg.screenshot(path=os.path.join(SHOTS, "drawer-desktop-success.png"))
    pg.keyboard.press("Escape")
    check("Esc closes drawer", not dlg(pg).is_visible())
    check("no console errors (journey)", len(errs) == 0, "; ".join(errs[:3]))
    c.close()

    # ---------- 2. non-emergency success + error/retry ----------
    c, pg, errs = open_page(browser, url=BASE + "?simulate=error")
    pg.locator("#hero .cta").click()
    pg.fill("#qf-postcode", "M20 2AA"); pg.click("dialog button:has-text('Next')")
    pg.locator("dialog label:has-text('Draughty or noisy')").click()
    pg.locator("dialog label:has-text('This week')").click()
    check("no 999 note for non-emergency", pg.locator("dialog [role=note]", has_text="999").count() == 0)
    pg.click("dialog button:has-text('Next')")
    pg.fill("#qf-name", "Tom"); pg.fill("#qf-phone", "+44 7340 843583")
    pg.click("dialog button[type=submit]")
    pg.wait_for_selector("dialog [role=alert]")
    alert = pg.locator("dialog [role=alert]").inner_text()
    check("error banner with tap-to-call fallback", "reach the server" in alert and pg.locator("dialog [role=alert] a[href^='tel:']").count() == 1)
    pg.screenshot(path=os.path.join(SHOTS, "drawer-desktop-error.png"))
    pg.click("dialog button[type=submit]")  # retry
    pg.wait_for_selector("text=ring you within 2 hours")
    check("non-emergency success copy", "Thanks Tom, Stuart's team will ring you within 2 hours (Mon-Sat)." in pg.locator("dialog").inner_text())
    c.close()

    # ---------- 3. CTA entry points + preselection ----------
    c, pg, errs = open_page(browser)
    check("hero has no postcode input", pg.locator("#hero input").count() == 0)
    pg.locator("#hero button.cta").click()
    check("hero CTA opens drawer at step 1", step_text(pg) == "Step 1 of 3")
    pg.keyboard.press("Escape")

    check("problem section removed", pg.locator("#problem-title").count() == 0 and "wrong with your windows" not in pg.locator("main").inner_text())
    check("price cards have no CTA", pg.locator("#pricing .cta").count() == 0)
    check("header has no CTA button", pg.locator("header .cta").count() == 0)
    ctas = pg.locator(".cta:not(dialog .cta):not(footer .cta):not(header .cta)")
    check("exactly 2 CTAs outside footer (hero + bottom)", ctas.count() == 2, str(ctas.count()))
    check("CTAs are in hero and final section", pg.locator("#hero .cta").count() == 1 and pg.locator("#get-quote .cta").count() == 1)
    opened = 0
    for i in range(ctas.count()):
        el = ctas.nth(i); el.scroll_into_view_if_needed(); el.click()
        if dlg(pg).is_visible(): opened += 1
        pg.keyboard.press("Escape")
    check(f"both CTAs open the same drawer ({opened}/2)", opened == 2)
    labels = set(ctas.all_inner_texts())
    check("one CTA label everywhere", labels == {"Get Your Free Quote"}, str(labels))
    check("final CTA has no 'no pushy sales' line", "no pushy sales" not in pg.locator("#get-quote").inner_text())
    check("no sticky bar", pg.locator(".mobile-bar").count() == 0)
    check("service area: 6 towns, no map, no note", pg.locator("#service-area li").count() == 6 and pg.locator("#service-area img").count() == 0 and "Not sure we cover" not in pg.locator("#service-area").inner_text())
    check("reviews heading is 'Reviews'", pg.locator("#reviews-title").inner_text().strip() == "Reviews")
    check("reviews: no counter text, no dots", "of 6" not in pg.locator("#reviews").inner_text() and pg.locator("#reviews [aria-label='Choose a review']").count() == 0)
    check("included list has 6 items", pg.locator("#how-it-works ul li").count() == 6)
    check("WhatsApp float visible on laptop", pg.locator("a[href^='https://wa.me/']").is_visible() and "Contact us" in pg.locator("a[href^='https://wa.me/']").inner_text())
    check("footer: fixed CTA hidden on laptop", pg.locator("footer .cta").count() == 1 and not pg.locator("footer .cta").is_visible())

    # ---------- 4. size selector, FAQ, sliders ----------
    pg.locator("#pricing label:has-text('Large')").click()
    check("size selector updates live (Large -> £195)", "£195" in pg.locator("#pricing").inner_text())
    pg.locator("#pricing label:has-text('Small')").click()
    check("size selector updates live (Small -> £95)", "£95" in pg.locator("#pricing").inner_text())
    check("pricing disclaimer removed", pg.locator("#pricing").get_by_text("No deposit.").count() == 0)
    check("trust strip removed", pg.get_by_text("Example accreditation badge").count() == 0 and pg.get_by_text("Every fitter, every job").count() == 0)

    first = pg.locator("#faq button[aria-expanded]").first
    check("FAQ first item open", first.get_attribute("aria-expanded") == "true")
    second = pg.locator("#faq button[aria-expanded]").nth(1)
    second.click()
    check("FAQ toggle opens item", second.get_attribute("aria-expanded") == "true")
    second.click()
    check("FAQ toggle closes item", second.get_attribute("aria-expanded") == "false")

    rng = pg.locator("#results input[type=range]")
    pg.evaluate("document.querySelector('#results input[type=range]').scrollIntoView({block:'center', behavior:'instant'})")
    pg.wait_for_timeout(300)
    rng.focus()
    pg.keyboard.press("ArrowLeft"); pg.keyboard.press("ArrowLeft")
    check("compare slider works with keyboard", rng.input_value() == "48", rng.input_value())
    box = rng.bounding_box()
    pg.mouse.move(box["x"] + box["width"] * 0.5, box["y"] + box["height"] * 0.5)
    pg.mouse.down(); pg.mouse.move(box["x"] + box["width"] * 0.8, box["y"] + box["height"] * 0.5, steps=6); pg.mouse.up()
    check("compare slider drags with pointer", int(rng.input_value()) > 70, rng.input_value())

    nxt = pg.locator("#reviews button[aria-label='Next review']")
    prev = pg.locator("#reviews button[aria-label='Previous review']")
    check("reviews: Previous disabled at start", prev.is_disabled())
    nxt.click(); pg.wait_for_timeout(700)
    check("reviews: Next advances", prev.is_enabled())
    pg.locator("#reviews [aria-roledescription=carousel] > div").first.focus()
    pg.keyboard.press("ArrowRight"); pg.wait_for_timeout(700)
    check("reviews: arrow keys work", prev.is_enabled())
    for _ in range(5):
        if nxt.is_disabled(): break
        nxt.click(); pg.wait_for_timeout(600)
    check("reviews: Next disabled at end", nxt.is_disabled())
    check("reviews chip removed", pg.get_by_text("Example reviews (fictional)").count() == 0 and pg.locator("#about dl").count() == 0)
    check("footer disclaimer present", "fictional business created for demonstration" in pg.locator("footer").inner_text())
    check("footer has only the mobile fixed CTA button", pg.locator("footer button").count() == 1)
    check("no console errors (entry points)", len(errs) == 0, "; ".join(errs[:3]))
    c.close()

    # ---------- 5. mobile: menu, footer phone ----------
    c, pg, errs = open_page(browser, width=390, height=844, has_touch=True, is_mobile=True)
    burger = pg.locator("header button[aria-controls=mobile-menu]")
    check("mobile: hamburger collapsed", burger.get_attribute("aria-expanded") == "false")
    burger.click()
    check("mobile: menu opens", burger.get_attribute("aria-expanded") == "true" and pg.locator("#mobile-menu").is_visible())
    pg.keyboard.press("Escape")
    check("mobile: Esc closes menu", burger.get_attribute("aria-expanded") == "false")
    check("mobile: focus returns to hamburger", pg.evaluate("document.activeElement === document.querySelector('header button[aria-controls=mobile-menu]')"))
    check("mobile: header phone icon visible, no CTA", pg.locator("header .cta").count() == 0 and pg.locator("header a[aria-label^='Call']").is_visible())
    check("mobile: WhatsApp float hidden", not pg.locator("a[href^='https://wa.me/']").is_visible())
    fc = pg.locator("footer .cta")
    check("mobile: fixed CTA visible at bottom of screen", fc.is_visible() and pg.evaluate("getComputedStyle(document.querySelector('footer .cta').closest('.fixed')).position") == "fixed")
    pg.evaluate("window.scrollTo(0, 1200)"); pg.wait_for_timeout(200)
    bb = fc.bounding_box()
    check("mobile: fixed CTA stays on screen after scrolling", bb is not None and bb["y"] + bb["height"] <= 844 and bb["y"] > 600, str(bb))
    ph = pg.locator("footer a[aria-label^='Call']"); pb = ph.bounding_box()
    check("mobile: phone button right of fixed CTA, in right corner", ph.is_visible() and pb["x"] >= bb["x"] + bb["width"] and pb["x"] + pb["width"] > 390 - 24 and abs(pb["y"] - bb["y"]) < 20, str((pb, bb)))
    fc.click(); pg.wait_for_timeout(300)
    check("mobile: fixed CTA opens drawer", dlg(pg).is_visible()); pg.keyboard.press("Escape")
    pg.screenshot(path=os.path.join(SHOTS, "mobile-footer.png"))
    pg.evaluate("window.scrollTo({top: 0, behavior: 'instant'})")
    pg.locator("#hero .cta").click(); pg.wait_for_timeout(400)
    pg.screenshot(path=os.path.join(SHOTS, "drawer-mobile-step1.png"))
    pg.fill("#qf-postcode", "SK4 0AB"); pg.click("dialog button:has-text('Next')")
    pg.locator("dialog label:has-text('Cracked or broken')").click()
    pg.locator("dialog label:has-text('Emergency today')").click()
    pg.wait_for_timeout(200)
    pg.screenshot(path=os.path.join(SHOTS, "drawer-mobile-step2.png"))
    pg.keyboard.press("Escape")
    # menu anchor lands below sticky header
    burger.click(); pg.locator("#mobile-menu a:has-text('Pricing')").click(); pg.wait_for_timeout(2500)
    top = pg.evaluate("document.querySelector('#pricing').getBoundingClientRect().top")
    check("anchor lands below sticky header", 60 <= top <= 90, f"top={top:.0f}")
    check("no console errors (mobile)", len(errs) == 0, "; ".join(errs[:3]))
    c.close()

    # ---------- 6. reduced motion ----------
    c, pg, errs = open_page(browser, reduced_motion="reduce")
    anim = pg.evaluate("""() => { const s=document.querySelector('.shape'); const w=document.querySelector('.divider-layer'); return [getComputedStyle(s).animationName, getComputedStyle(w).animationName]; }""")
    check("reduced motion: shapes + waves static", anim == ["none", "none"], str(anim))
    dot = pg.evaluate("getComputedStyle(document.querySelector('.line-div__dot')).display")
    check("reduced motion: line dot hidden", dot == "none")
    pg.locator("#hero .cta").hover()
    t = pg.evaluate("getComputedStyle(document.querySelector('#hero .cta')).transform")
    check("reduced motion: CTA no lift", t in ("none", "matrix(1, 0, 0, 1, 0, 0)"), t)
    c.close()

    # ---------- 7. counts ----------
    c, pg, errs = open_page(browser)
    nshapes = pg.evaluate("document.querySelectorAll('.shape').length")
    check("ambient shapes: 7+6+3+3+2 = 21 in DOM", nshapes == 21, str(nshapes))
    c.close()
    browser.close()

fails = [n for n, ok in results if not ok]
print(f"\n{len(results) - len(fails)}/{len(results)} checks passed")
sys.exit(1 if fails else 0)
