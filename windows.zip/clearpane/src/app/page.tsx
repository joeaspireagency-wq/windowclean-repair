import { QuoteProvider } from "@/components/quote/QuoteProvider";
import { Header } from "@/components/Header";
import { WhatsAppFloat } from "@/components/WhatsAppFloat";
import { Footer } from "@/components/Footer";
import { SectionDivider } from "@/components/motion/SectionDivider";
import { Hero } from "@/components/sections/Hero";
import { Services } from "@/components/sections/Services";
import { HowItWorks } from "@/components/sections/HowItWorks";
import { Pricing } from "@/components/sections/Pricing";
import { Promises } from "@/components/sections/Promises";
import { CaseStudy } from "@/components/sections/CaseStudy";
import { Reviews } from "@/components/sections/Reviews";
import { Faq } from "@/components/sections/Faq";
import { About } from "@/components/sections/About";
import { ServiceArea } from "@/components/sections/ServiceArea";
import { FinalCta } from "@/components/sections/FinalCta";

/**
 * Page order follows the layout spec (15 sections). Dividers replace every
 * border between sections: waves where the background changes, a drawing line
 * where neighbours share a colour.
 */
export default function Home() {
  return (
    <QuoteProvider>
      <span id="top" />
      <Header />
      <main id="main">
        <Hero />
        <SectionDivider from="navy" to="offwhite" profile={1} />
        <Services />
        <SectionDivider from="offwhite" to="ice" profile={3} />
        <HowItWorks />
        <SectionDivider from="ice" to="ice" variant="line" />
        <Pricing />
        <SectionDivider from="ice" to="navy" profile={3} flip />
        <Promises />
        <SectionDivider from="navy" to="offwhite" profile={1} />
        <CaseStudy />
        <SectionDivider from="offwhite" to="ice" profile={2} flip />
        <Reviews />
        <SectionDivider from="ice" to="offwhite" profile={3} />
        <Faq />
        <SectionDivider from="offwhite" to="ice" profile={1} flip />
        <About />
        <SectionDivider from="ice" to="offwhite" profile={2} />
        <ServiceArea />
        <SectionDivider from="offwhite" to="navy-mid" profile={3} flip />
        <FinalCta />
      </main>
      <SectionDivider from="navy" to="navy" variant="line" />
      <Footer />
      <WhatsAppFloat />
    </QuoteProvider>
  );
}
