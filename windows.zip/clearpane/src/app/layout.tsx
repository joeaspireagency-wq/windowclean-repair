import type { Metadata, Viewport } from "next";
import localFont from "next/font/local";
import type { CSSProperties, ReactNode } from "react";
import "./globals.css";
import { siteConfig } from "@/site.config";
import { hexToRgbTriplet } from "@/lib/color";
import { MotionRuntime } from "@/components/motion/MotionRuntime";
import "@/lib/validate-config"; // fails the build if site.config.ts is invalid

// Self-hosted at build time (files in src/fonts, from @fontsource-variable).
const outfit = localFont({
  src: "../fonts/outfit-latin-wght-normal.woff2",
  weight: "100 900",
  variable: "--font-outfit",
  display: "swap",
});
const inter = localFont({
  src: "../fonts/inter-latin-wght-normal.woff2",
  weight: "100 900",
  variable: "--font-inter",
  display: "swap",
});

export const metadata: Metadata = {
  title: `${siteConfig.business.name} | Fixed-price glazing in ${siteConfig.business.location}`,
  description: `${siteConfig.hero.subhead} Serving ${siteConfig.business.areaServed}. Fictional demonstration site.`,
  robots: { index: false, follow: false }, // demonstration only
};

export const viewport: Viewport = {
  themeColor: siteConfig.colours.navy,
  width: "device-width",
  initialScale: 1,
};

/** Colour tokens from site.config.ts override the @theme defaults. */
function themeVars(): CSSProperties {
  const c = siteConfig.colours;
  return {
    "--color-navy": c.navy,
    "--color-navy-mid": c.navyMid,
    "--color-ice": c.ice,
    "--color-offwhite": c.offwhite,
    "--color-pane": c.pane,
    "--color-orange": c.orange,
    "--color-orange-hover": c.orangeHover,
    "--color-charcoal": c.charcoal,
    "--color-muted": c.muted,
    "--rgb-navy": hexToRgbTriplet(c.navy),
    "--rgb-ice": hexToRgbTriplet(c.ice),
    "--rgb-offwhite": hexToRgbTriplet(c.offwhite),
    "--rgb-orange": hexToRgbTriplet(c.orange),
  } as CSSProperties;
}

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en-GB" className={`${outfit.variable} ${inter.variable}`} style={themeVars()}>
      <body className="relative">
        <a
          href="#main"
          className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[60] focus:rounded-full focus:bg-offwhite focus:px-5 focus:py-3 focus:font-semibold focus:text-navy"
        >
          Skip to content
        </a>
        {children}
        <MotionRuntime />
      </body>
    </html>
  );
}
