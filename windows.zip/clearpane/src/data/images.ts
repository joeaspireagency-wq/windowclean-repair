import { z } from "zod";

/**
 * Image manifest. Components reference images by id, never by path.
 * To use real photography: replace the file in /public/images with one of the
 * same name (and aspect ratio), or edit the entry below and set
 * isPlaceholder: false.
 *
 * Every entry below is a PLACEHOLDER - replace for real client (generated SVG
 * illustration, the results photos are supplied stand-ins). No external URLs.
 */

export const imageIdSchema = z.enum([
  "hero-bg",
  "stuart-portrait",
  "before-misted",
  "after-clear",
]);
export type ImageId = z.infer<typeof imageIdSchema>;

const imageSchema = z.object({
  id: imageIdSchema,
  src: z.string().regex(/^(\/images\/|data:image\/)/),
  alt: z.string(),
  width: z.number().int().positive(),
  height: z.number().int().positive(),
  aspectRatio: z.string().regex(/^\d+\s*\/\s*\d+$/),
  sizes: z.string().min(1),
  priority: z.boolean(),
  objectPosition: z.string(),
  blurDataURL: z.string().optional(),
  isPlaceholder: z.boolean(),
  credit: z.string(),
});
export type SiteImage = z.infer<typeof imageSchema>;


const entries = [
  {
    id: "hero-bg",
    src: "/images/hero/hero-bg.jpg",
    alt: "",
    width: 1280,
    height: 662,
    aspectRatio: "1280 / 662",
    sizes: "100vw",
    priority: false,
    objectPosition: "50% 50%",
    isPlaceholder: true, // PLACEHOLDER - replace with a real photo for a real client
    credit: "Supplied by the site owner (slightly blurred, decorative background)",
  },
  {
    id: "stuart-portrait",
    src: "/images/about/stuart-portrait.jpg",
    alt: "Stuart Hale, founder of Clearpane, smiling in red work overalls while fitting a window",
    width: 800,
    height: 1000,
    aspectRatio: "4 / 5",
    sizes: "(min-width: 1024px) 420px, (min-width: 640px) 50vw, 90vw",
    priority: false,
    objectPosition: "50% 20%",
    isPlaceholder: true, // PLACEHOLDER - replace with the real owner photo for a real client
    credit: "Supplied by the site owner (AI-generated stand-in)",
  },
  {
    id: "before-misted",
    src: "/images/results/before-misted.jpg",
    alt: "Three bedroom windows with fog and condensation trapped between the panes",
    width: 1400,
    height: 1050,
    aspectRatio: "4 / 3",
    sizes: "(min-width: 1024px) 960px, 100vw",
    priority: false,
    objectPosition: "50% 50%",
    isPlaceholder: true, // PLACEHOLDER - replace for real client
    credit: "Supplied by the site owner (AI-generated stand-in)",
  },
  {
    id: "after-clear",
    src: "/images/results/after-clear.jpg",
    alt: "The same three windows with crystal clear glass, still in their original frames",
    width: 1400,
    height: 1050,
    aspectRatio: "4 / 3",
    sizes: "(min-width: 1024px) 960px, 100vw",
    priority: false,
    objectPosition: "50% 50%",
    isPlaceholder: true, // PLACEHOLDER - replace for real client
    credit: "Supplied by the site owner (AI-generated stand-in)",
  },
] satisfies SiteImage[];

const parsed = z.array(imageSchema).parse(entries);
export const images: Record<ImageId, SiteImage> = Object.fromEntries(
  parsed.map((img) => [img.id, img]),
) as Record<ImageId, SiteImage>;

export function getImage(id: ImageId): SiteImage {
  return images[id];
}
