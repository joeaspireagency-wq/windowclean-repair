import { z } from "zod";
import { problemSchema, urgencySchema } from "@/lib/quote/schema";
// NOTE: import this file only from server code (src/lib/validate-config.ts) so Zod stays out of the client bundle.

/**
 * Strict schema for src/site.config.ts. The config is parsed at module load,
 * so a bad config fails `next build`.
 */

const hex = z.string().regex(/^#[0-9A-Fa-f]{6}$/, "Expected a 6-digit hex colour");
const nonEmpty = z.string().trim().min(1);

export const iconNameSchema = z.enum([
  "misted", "cracked", "emergency", "repair", "door", "draught",
  "shield", "ruler", "sparkles", "pound", "handshake",
  "file", "camera", "clock", "check", "star", "key",
]);
export type IconName = z.infer<typeof iconNameSchema>;

export const jobIdSchema = z.enum(["misted-unit", "broken-pane", "window-repair", "emergency"]);
export type JobId = z.infer<typeof jobIdSchema>;

export const sizeIdSchema = z.enum(["small", "medium", "large"]);
export type SizeId = z.infer<typeof sizeIdSchema>;

/* ---------- ambient shapes ---------- */
export const shapeSchema = z.object({
  kind: z.enum(["ring", "disc", "line"]),
  /** Position as % of the section box. */
  x: z.number().min(-20).max(110),
  y: z.number().min(-20).max(110),
  size: z.number().min(80).max(400),
  tone: z.enum(["ice", "offwhite", "orange", "navy"]),
  opacity: z.number().min(0.04).max(0.18),
  /** Seconds. Every shape on the site needs its own value. */
  duration: z.number().min(18).max(45),
  /** Negative so each shape is mid-drift on load. */
  delay: z.number().max(0),
  dx: z.number().min(-70).max(70),
  dy: z.number().min(-70).max(70),
  rotate: z.number().min(-8).max(8).optional(),
  dashed: z.boolean().optional(),
  curved: z.boolean().optional(),
  /** Hidden below 640px so mobile renders about half the shapes. */
  hideOnMobile: z.boolean().optional(),
});
export type ShapeSpec = z.infer<typeof shapeSchema>;

const shapeSets = z.object({
  hero: z.array(shapeSchema).length(7),
  promises: z.array(shapeSchema).length(5),
  finalCta: z.array(shapeSchema).length(6),
  about: z.array(shapeSchema).length(3),
  repair: z.array(shapeSchema).length(3),
});

/* ---------- main schema ---------- */
export const siteConfigSchema = z
  .object({
    business: z.object({
      name: nonEmpty,
      shortName: nonEmpty,
      location: nonEmpty,
      areaServed: nonEmpty,
      yearsTrading: z.number().int().positive(),
      teamSize: z.number().int().positive(),
    }),
    owner: z.object({
      name: nonEmpty,
      firstName: nonEmpty,
      age: z.number().int(),
      role: nonEmpty,
      line: nonEmpty,
      portraitCaption: nonEmpty,
      story: z.array(nonEmpty).min(2),
    }),
    contact: z.object({
      phone: nonEmpty,
      phoneHref: z.string().startsWith("tel:"),
      whatsappHref: z.string().startsWith("https://wa.me/"),
      whatsappLabel: nonEmpty,
      email: z.email(),
      addressLines: z.array(nonEmpty).min(2),
      hours: z.array(z.object({ days: nonEmpty, time: nonEmpty })).min(1),
    }),
    ctaLabel: z.literal("Get Your Free Quote"),
    ctaMicrocopy: nonEmpty,
    stats: z.object({
      rating: z.number().min(0).max(5),
      reviewCount: z.number().int().positive(),
      windowsFixed: nonEmpty,
    }),
    nav: z.array(z.object({ label: nonEmpty, href: z.string().startsWith("#") })).length(4),
    hero: z.object({
      headline: nonEmpty,
      subhead: nonEmpty,
      bullets: z.array(nonEmpty).length(3),
      postcodeLabel: nonEmpty,
      postcodePlaceholder: nonEmpty,
      teamLine: nonEmpty,
    }),
    problems: z.object({
      headline: nonEmpty,
      items: z.array(z.object({ id: problemSchema, label: nonEmpty, hint: nonEmpty })).length(5),
    }),
    urgency: z.array(z.object({ id: urgencySchema, label: nonEmpty })).length(3),
    emergencyNote: nonEmpty,
    services: z.object({
      headline: nonEmpty,
      items: z.array(z.object({ title: nonEmpty, text: nonEmpty, icon: iconNameSchema })).length(6),
    }),
    how: z.object({
      headline: nonEmpty,
      steps: z.array(z.object({ title: nonEmpty, text: nonEmpty })).length(3),
      includedHeadline: nonEmpty,
      included: z.array(nonEmpty).min(6),
    }),
    pricing: z.object({
      headline: nonEmpty,
      intro: nonEmpty,
      sizes: z.array(z.object({ id: sizeIdSchema, label: nonEmpty, range: nonEmpty })).length(3),
      defaultSize: sizeIdSchema,
      cards: z
        .array(
          z.object({
            id: jobIdSchema,
            title: nonEmpty,
            blurb: nonEmpty,
            unit: z.string().optional(),
            bySize: z.record(sizeIdSchema, z.number().int().positive()).optional(),
            flatFrom: z.number().int().positive().optional(),
            note: z.string().optional(),
            badge: z.string().optional(),
            problem: problemSchema,
            urgency: urgencySchema.optional(),
          }),
        )
        .length(4),
      multiUnitNote: nonEmpty,
    }),
    guarantees: z.object({
      headline: nonEmpty,
      items: z.array(z.object({ title: nonEmpty, text: nonEmpty, icon: iconNameSchema })).length(4),
    }),
    caseStudy: z.object({
      headline: nonEmpty,
      beforeLabel: nonEmpty,
      afterLabel: nonEmpty,
      stats: z.array(z.object({ label: nonEmpty, value: nonEmpty })).length(4),
      comparison: z.object({ label: nonEmpty, value: nonEmpty, note: nonEmpty }),
      quote: nonEmpty,
      quoteBy: nonEmpty,
    }),
    reviews: z.object({
      headline: nonEmpty,
      items: z
        .array(z.object({ name: nonEmpty, town: nonEmpty, job: nonEmpty, quote: nonEmpty }))
        .length(6),
    }),
    faqs: z.object({
      headline: nonEmpty,
      items: z.array(z.object({ q: nonEmpty, a: nonEmpty })).length(7),
      closing: nonEmpty,
    }),
    serviceArea: z.object({
      headline: nonEmpty,
      intro: nonEmpty,
      towns: z.array(nonEmpty).length(6),
    }),
    finalCta: z.object({ headline: nonEmpty, subhead: nonEmpty }),
    footer: z.object({
      blurb: nonEmpty,
      legal: z.array(z.object({ label: nonEmpty, href: z.string() })).length(3),
    }),
    colours: z.object({
      navy: hex, navyMid: hex, ice: hex, offwhite: hex, pane: hex,
      orange: hex, orangeHover: hex, charcoal: hex, muted: hex,
    }),
    disclaimers: z.object({
      footer: nonEmpty,
    }),
    shapes: shapeSets,
  })
  .superRefine((cfg, ctx) => {
    // Every pricing card needs either size prices or a flat "from" price.
    cfg.pricing.cards.forEach((card, i) => {
      const hasSizes = card.bySize && Object.keys(card.bySize).length === 3;
      if (!hasSizes && !card.flatFrom) {
        ctx.addIssue({ code: "custom", path: ["pricing", "cards", i], message: "Card needs bySize (3 sizes) or flatFrom" });
      }
    });

    // Ambient shape guard rails: opacity ceilings per variant and unique timings.
    const durations = new Set<number>();
    const check = (key: keyof typeof cfg.shapes, variant: "dark" | "light") => {
      cfg.shapes[key].forEach((s, i) => {
        const path = ["shapes", key, i];
        if (durations.has(s.duration)) {
          ctx.addIssue({ code: "custom", path, message: `Duplicate shape duration ${s.duration}s` });
        }
        durations.add(s.duration);
        if (variant === "light") {
          if (s.tone !== "navy" || s.opacity > 0.07) {
            ctx.addIssue({ code: "custom", path, message: "Light shapes must be navy, max opacity 0.07" });
          }
        } else if (s.tone === "orange") {
          if (s.kind !== "disc" || s.opacity > 0.1) {
            ctx.addIssue({ code: "custom", path, message: "Orange shapes must be discs, max opacity 0.10" });
          }
        } else if (s.tone === "navy" || s.opacity > 0.18) {
          ctx.addIssue({ code: "custom", path, message: "Dark shapes: ice/offwhite only, max opacity 0.18" });
        }
        if (s.kind === "line" && s.size > 260) {
          ctx.addIssue({ code: "custom", path, message: "Lines are 120-260px" });
        }
      });
    };
    check("hero", "dark");
    check("promises", "dark");
    check("finalCta", "dark");
    check("about", "light");
    check("repair", "light");
  });

export type SiteConfig = z.infer<typeof siteConfigSchema>;
