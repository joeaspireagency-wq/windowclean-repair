import "server-only";
import { siteConfigSchema } from "@/lib/config-schema";
import { siteConfig } from "@/site.config";

/**
 * Build-time guard. Imported by the root layout (a server component), so
 * `next build` runs this parse while prerendering and fails with a clear Zod
 * error if site.config.ts doesn't match the schema.
 */
siteConfigSchema.parse(siteConfig);
