/**
 * Dependency-free validators shared by the hero field (loaded on first paint)
 * and the Zod quote schema (lazy-loaded with the drawer). Keeping these tiny
 * keeps Zod out of the initial JavaScript.
 */

/** UK postcode: outward + inward code, space optional, case-insensitive. */
export const UK_POSTCODE_RE =
  /^(GIR ?0AA|[A-PR-UWYZ]([0-9]{1,2}|([A-HK-Y][0-9]([0-9ABEHMNPRV-Y])?)|[0-9][A-HJKPS-UW]) ?[0-9][ABD-HJLNP-UW-Z]{2})$/i;

export const POSTCODE_REQUIRED = "Enter your postcode so we can check we cover you.";
export const POSTCODE_INVALID = "That doesn't look like a UK postcode. Try something like SK4 0AB.";

/** Returns an error message, or undefined when the postcode is valid. */
export function postcodeError(value: string): string | undefined {
  const v = value.trim();
  if (!v) return POSTCODE_REQUIRED;
  if (!UK_POSTCODE_RE.test(v)) return POSTCODE_INVALID;
  return undefined;
}

/** UK phone: 0 or +44 followed by 9-10 digits (spaces, brackets and dashes ignored). */
export function isUkPhone(value: string): boolean {
  const compact = value.replace(/[\s()-]/g, "");
  return /^(?:\+44|0)[1-37]\d{8,9}$/.test(compact);
}
