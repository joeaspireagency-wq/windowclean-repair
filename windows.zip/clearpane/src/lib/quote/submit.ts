import { AdapterNetworkError, demoAdapter, type QuoteAdapter } from "./adapter";
import { quoteReceiptSchema, quoteRequestSchema, type QuoteReceipt } from "./schema";

export type QuoteErrorKind = "validation" | "network" | "unknown";

export type QuoteError = {
  kind: QuoteErrorKind;
  message: string;
  /** Field-level messages when kind is "validation". */
  fieldErrors?: Partial<Record<string, string>>;
};

export type QuoteResult =
  | { ok: true; receipt: QuoteReceipt }
  | { ok: false; error: QuoteError };

/**
 * Validate, submit through the adapter, and map every failure to a typed
 * error. Never throws.
 */
export async function submitQuote(
  input: unknown,
  adapter: QuoteAdapter = demoAdapter,
): Promise<QuoteResult> {
  const parsed = quoteRequestSchema.safeParse(input);
  if (!parsed.success) {
    const fieldErrors: Record<string, string> = {};
    for (const issue of parsed.error.issues) {
      const key = String(issue.path[0] ?? "form");
      fieldErrors[key] ??= issue.message;
    }
    return {
      ok: false,
      error: { kind: "validation", message: "Some details need another look.", fieldErrors },
    };
  }

  try {
    const receipt = quoteReceiptSchema.parse(await adapter.submit(parsed.data));
    return { ok: true, receipt };
  } catch (err) {
    if (err instanceof AdapterNetworkError || (err instanceof TypeError && /fetch|network/i.test(err.message))) {
      return {
        ok: false,
        error: { kind: "network", message: "We couldn't reach the server. Check your connection and try again." },
      };
    }
    return {
      ok: false,
      error: { kind: "unknown", message: "Something went wrong on our side. Please try again." },
    };
  }
}
