import type { QuoteReceipt, QuoteRequest } from "./schema";

/**
 * A QuoteAdapter turns a validated request into a receipt.
 * The UI only ever talks to `submitQuote` (see submit.ts), so a real adapter
 * (a free form service, an email API, a CRM) can be dropped in later without
 * touching any component.
 */
export interface QuoteAdapter {
  readonly name: string;
  submit(request: QuoteRequest): Promise<QuoteReceipt>;
}

export class AdapterNetworkError extends Error {
  constructor(message = "Network request failed") {
    super(message);
    this.name = "AdapterNetworkError";
  }
}

export interface DemoAdapterOptions {
  /** Simulated latency in ms. Defaults to about 800ms. */
  latencyMs?: number;
  /** Force a failure, used only to demonstrate the error + retry UI. */
  fail?: "network" | "unknown";
}

/**
 * DEMO adapter. PLACEHOLDER - replace for real client.
 * Makes NO network call and stores NOTHING (no localStorage, cookies or
 * logging of personal data). It only waits, then returns a typed receipt.
 */
export function createDemoAdapter(options: DemoAdapterOptions = {}): QuoteAdapter {
  const { latencyMs = 800, fail } = options;
  return {
    name: "demo",
    async submit(request) {
      await new Promise<void>((resolve) => setTimeout(resolve, latencyMs));
      if (fail === "network") throw new AdapterNetworkError();
      if (fail === "unknown") throw new Error("Simulated failure");
      return {
        reference: `DEMO-${Math.random().toString(36).slice(2, 8).toUpperCase()}`,
        receivedAt: new Date().toISOString(),
        urgency: request.urgency,
        name: request.name,
        callbackWithinMinutes: request.urgency === "emergency" ? 30 : 120,
        demo: true,
      };
    },
  };
}

export const demoAdapter: QuoteAdapter = createDemoAdapter();
