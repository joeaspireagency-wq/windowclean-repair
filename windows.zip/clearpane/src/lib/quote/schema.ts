import { z } from "zod";

/**
 * Quote request schema. Single source of truth for the form, the connector
 * and the site config (problem / urgency ids).
 */

import { POSTCODE_INVALID, POSTCODE_REQUIRED, UK_POSTCODE_RE, isUkPhone } from "./patterns";

export const problemIds = ["misted", "cracked", "wont-close", "draughty", "unsure"] as const;
export const urgencyIds = ["emergency", "this-week", "planning"] as const;

export const problemSchema = z.enum(problemIds, { error: "Pick the option closest to your problem." });
export const urgencySchema = z.enum(urgencyIds, { error: "Tell us how urgent it is." });

export const postcodeSchema = z
  .string()
  .trim()
  .min(1, POSTCODE_REQUIRED)
  .regex(UK_POSTCODE_RE, POSTCODE_INVALID);

export const nameSchema = z
  .string()
  .trim()
  .min(2, "Enter your name so Stuart knows who to ask for.")
  .max(80, "That name is a bit long. Please shorten it.");

export const phoneSchema = z
  .string()
  .trim()
  .min(1, "Enter a phone number so we can ring you back.")
  .refine(isUkPhone, "That doesn't look like a UK phone number. Try 07700 900142.");

export const quoteRequestSchema = z.object({
  postcode: postcodeSchema,
  problem: problemSchema,
  urgency: urgencySchema,
  name: nameSchema,
  phone: phoneSchema,
});

export type QuoteRequest = z.infer<typeof quoteRequestSchema>;
export type ProblemId = z.infer<typeof problemSchema>;
export type UrgencyId = z.infer<typeof urgencySchema>;

/** Per-step slices so each step validates on its own. */
export const stepSchemas = {
  1: quoteRequestSchema.pick({ postcode: true }),
  2: quoteRequestSchema.pick({ problem: true, urgency: true }),
  3: quoteRequestSchema.pick({ name: true, phone: true }),
} as const;

export const quoteReceiptSchema = z.object({
  reference: z.string(),
  receivedAt: z.string(),
  urgency: urgencySchema,
  name: z.string(),
  callbackWithinMinutes: z.number(),
  demo: z.literal(true),
});
export type QuoteReceipt = z.infer<typeof quoteReceiptSchema>;
