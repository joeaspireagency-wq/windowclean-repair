/** "#0B2545" -> "11 37 69" (space-separated for rgb(var(--x) / alpha)). */
export function hexToRgbTriplet(hex: string): string {
  const n = parseInt(hex.slice(1), 16);
  return `${(n >> 16) & 255} ${(n >> 8) & 255} ${n & 255}`;
}
