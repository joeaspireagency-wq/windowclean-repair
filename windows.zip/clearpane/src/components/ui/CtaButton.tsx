"use client";

import { ArrowRight } from "lucide-react";
import { siteConfig } from "@/site.config";
import { useQuote, type QuotePreset } from "@/components/quote/QuoteProvider";

type Props = {
  /** Which form state to open with (problem, urgency, step). */
  preset?: QuotePreset;
  /** "dark" when sitting on navy so the focus ring turns off-white. */
  on?: "dark" | "light";
  size?: "sm" | "md" | "lg";
  block?: boolean;
  className?: string;
  pulse?: boolean;
};

/**
 * THE conversion button. One label (siteConfig.ctaLabel), one orange style,
 * and it always opens the same quote drawer.
 */
export function CtaButton({ preset, on = "light", size = "md", block = false, className = "", pulse = false }: Props) {
  const { openQuote } = useQuote();
  return (
    <button
      type="button"
      className={`cta ${pulse ? "cta-pulse" : ""} ${className}`}
      data-on={on}
      data-size={size}
      data-block={block}
      aria-haspopup="dialog"
      onClick={() => openQuote(preset)}
    >
      {siteConfig.ctaLabel}
      {size !== "sm" && <ArrowRight className="h-5 w-5 shrink-0" aria-hidden />}
    </button>
  );
}
