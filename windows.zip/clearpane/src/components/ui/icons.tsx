import type { SVGProps } from "react";
import {
  Camera, Check, Clock, DoorOpen, FileText, Handshake, KeyRound, PoundSterling,
  Ruler, ShieldAlert, ShieldCheck, Sparkles, Star, Wrench,
} from "lucide-react";
import type { IconName } from "@/lib/config-schema";
import type { ProblemId } from "@/lib/quote/schema";

type P = SVGProps<SVGSVGElement>;

const base = {
  viewBox: "0 0 48 48",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 2.5,
  strokeLinecap: "round",
  strokeLinejoin: "round",
  "aria-hidden": true,
  focusable: false,
} as const;

/** Window with fog and droplets between the panes. */
export function MistedIcon(props: P) {
  return (
    <svg {...base} {...props}>
      <rect x="7" y="6" width="34" height="36" rx="4" />
      <path d="M24 6v36M7 24h34" opacity=".45" />
      <path d="M13 17c2-2 4 2 6 0M29 15c2-2 4 2 6 0M12 31c2-2 4 2 6 0M30 33c2-2 4 2 6 0" />
      <circle cx="17" cy="38" r="1.4" fill="currentColor" stroke="none" />
      <circle cx="33" cy="26" r="1.4" fill="currentColor" stroke="none" />
    </svg>
  );
}
/** Window with a radiating crack. */
export function CrackedIcon(props: P) {
  return (
    <svg {...base} {...props}>
      <rect x="7" y="6" width="34" height="36" rx="4" />
      <path d="M26 6l-4 11 7 4-9 6 5 4-3 11" />
      <path d="M22 17l-9-3M29 21l9-2M20 27l-8 5" opacity=".6" />
    </svg>
  );
}
/** Window left ajar with a lock. */
export function WontCloseIcon(props: P) {
  return (
    <svg {...base} {...props}>
      <path d="M8 8l22 4v26L8 42z" />
      <path d="M30 12l10 2v24l-10 2" opacity=".5" />
      <circle cx="24" cy="26" r="1.8" fill="currentColor" stroke="none" />
      <rect x="31" y="22" width="12" height="9" rx="2" />
      <path d="M34 22v-3a3 3 0 016 0v3" />
    </svg>
  );
}
/** Wind lines blowing past a window. */
export function DraughtyIcon(props: P) {
  return (
    <svg {...base} {...props}>
      <rect x="25" y="6" width="17" height="36" rx="3" opacity=".5" />
      <path d="M4 17h20a5 5 0 10-5-5" />
      <path d="M4 25h26a5 5 0 11-5 5" />
      <path d="M4 33h14" />
    </svg>
  );
}
/** Window with a question mark. */
export function UnsureIcon(props: P) {
  return (
    <svg {...base} {...props}>
      <rect x="7" y="6" width="34" height="36" rx="4" />
      <path d="M19 19a5 5 0 119 2c-2 2-4 3-4 6" />
      <circle cx="24" cy="33" r="1.6" fill="currentColor" stroke="none" />
    </svg>
  );
}

const problemIcons: Record<ProblemId, (p: P) => React.JSX.Element> = {
  misted: MistedIcon,
  cracked: CrackedIcon,
  "wont-close": WontCloseIcon,
  draughty: DraughtyIcon,
  unsure: UnsureIcon,
};

export function ProblemIcon({ id, ...props }: { id: ProblemId } & P) {
  const Cmp = problemIcons[id];
  return <Cmp {...props} />;
}

type LucideLike = (p: { size?: number; className?: string; "aria-hidden"?: boolean }) => React.JSX.Element;

const named: Record<IconName, LucideLike | ((p: P) => React.JSX.Element)> = {
  misted: MistedIcon,
  cracked: CrackedIcon,
  draught: DraughtyIcon,
  emergency: ShieldAlert as LucideLike,
  repair: Wrench as LucideLike,
  door: DoorOpen as LucideLike,
  shield: ShieldCheck as LucideLike,
  ruler: Ruler as LucideLike,
  sparkles: Sparkles as LucideLike,
  pound: PoundSterling as LucideLike,
  handshake: Handshake as LucideLike,
  file: FileText as LucideLike,
  camera: Camera as LucideLike,
  clock: Clock as LucideLike,
  check: Check as LucideLike,
  star: Star as LucideLike,
  key: KeyRound as LucideLike,
};

/** Renders any config icon by name at a consistent size. */
export function Icon({ name, className = "h-7 w-7" }: { name: IconName; className?: string }) {
  const Cmp = named[name] as (p: { className?: string; "aria-hidden"?: boolean }) => React.JSX.Element;
  return <Cmp className={className} aria-hidden />;
}

/** Five amber-orange stars (small highlight, so orange is allowed). */
export function Stars({ className = "h-5 w-5" }: { className?: string }) {
  return (
    <span className="inline-flex gap-0.5 text-orange" aria-hidden>
      {Array.from({ length: 5 }).map((_, i) => (
        <Star key={i} className={className} fill="currentColor" strokeWidth={0} />
      ))}
    </span>
  );
}

/** Window-pane logo mark. */
export function LogoMark({ className = "h-9 w-9" }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 40" className={className} aria-hidden focusable={false}>
      <rect x="2" y="2" width="36" height="36" rx="9" fill="var(--color-navy-mid)" />
      <rect x="9" y="9" width="22" height="22" rx="3" fill="var(--color-ice)" />
      <path d="M20 9v22M9 20h22" stroke="var(--color-navy-mid)" strokeWidth="2.2" />
      <path d="M12 28l8-8" stroke="#fff" strokeWidth="2.4" strokeLinecap="round" opacity=".85" />
      <circle cx="31" cy="9" r="3.2" fill="var(--color-orange)" />
    </svg>
  );
}
