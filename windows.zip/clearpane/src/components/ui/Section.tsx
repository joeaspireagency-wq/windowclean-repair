import type { ReactNode } from "react";

type Tone = "navy" | "ice" | "offwhite";

const BG: Record<Tone, string> = {
  navy: "bg-navy text-offwhite on-dark",
  ice: "bg-ice text-charcoal",
  offwhite: "bg-offwhite text-charcoal",
};

type Props = {
  id?: string;
  tone: Tone;
  children: ReactNode;
  /** Extra classes for the outer <section>. */
  className?: string;
  /** Ambient shapes element rendered behind the content. */
  shapes?: ReactNode;
  labelledBy?: string;
};

/**
 * Standard section shell: background, vertical rhythm, centred container.
 * With `shapes`, content is lifted to z-10 above the decorative layer.
 */
export function Section({ id, tone, children, className = "", shapes, labelledBy }: Props) {
  return (
    <section
      id={id}
      aria-labelledby={labelledBy}
      className={`relative ${shapes ? "isolate overflow-hidden" : ""} ${BG[tone]} py-[2.625rem] sm:py-[3.75rem] ${className}`}
    >
      {shapes}
      <div className="relative z-10 mx-auto w-full max-w-[1200px] px-5 sm:px-8">{children}</div>
    </section>
  );
}

export function SectionHeading({
  id,
  eyebrow,
  children,
  sub,
  tone = "light",
  align = "center",
}: {
  id: string;
  eyebrow?: string;
  children: ReactNode;
  sub?: ReactNode;
  tone?: "light" | "dark";
  align?: "center" | "left";
}) {
  return (
    <div className={`mb-10 sm:mb-12 ${align === "center" ? "mx-auto max-w-3xl text-center" : "max-w-3xl"}`}>
      {eyebrow && (
        <p className={`mb-3 text-sm font-semibold uppercase tracking-[0.14em] ${tone === "dark" ? "text-ice" : "text-navy-mid"}`}>
          {eyebrow}
        </p>
      )}
      <h2 id={id} className={`text-[1.75rem] sm:text-4xl lg:text-[2.5rem] ${tone === "dark" ? "text-offwhite" : "text-navy"}`}>
        {children}
      </h2>
      {sub && <p className={`mt-4 text-lg ${tone === "dark" ? "text-ice/90" : "text-muted"}`}>{sub}</p>}
    </div>
  );
}

/** Small "Fictional example" style chip. */
export function Chip({ children, tone = "light" }: { children: ReactNode; tone?: "light" | "dark" }) {
  return (
    <span
      className={`inline-flex items-center rounded-full border px-3 py-1 text-sm font-semibold ${
        tone === "dark" ? "border-ice/40 bg-white/10 text-ice" : "border-navy/25 bg-white text-navy"
      }`}
    >
      {children}
    </span>
  );
}
