import Image from "next/image";
import { getImage, type ImageId } from "@/data/images";

type Props = {
  id: ImageId;
  className?: string;
  /** Overrides the manifest alt text (e.g. "" for purely decorative use). */
  alt?: string;
  rounded?: boolean;
};

/**
 * Renders an image by manifest id inside an aspect-ratio box (no layout
 * shift, never stretched). Lazy by default; `priority: true` in the manifest
 * makes it eager with high fetch priority.
 */
export function SiteImage({ id, className = "", alt, rounded = true }: Props) {
  const img = getImage(id);
  return (
    <div
      className={`relative w-full overflow-hidden ${rounded ? "rounded-xl" : ""} ${className}`}
      style={{ aspectRatio: img.aspectRatio }}
      data-placeholder={img.isPlaceholder ? "true" : undefined}
    >
      <Image
        src={img.src}
        alt={alt ?? img.alt}
        fill
        sizes={img.sizes}
        quality={85}
        loading={img.priority ? "eager" : "lazy"}
        fetchPriority={img.priority ? "high" : "auto"}
        placeholder={img.blurDataURL ? "blur" : "empty"}
        blurDataURL={img.blurDataURL}
        className="object-cover"
        style={{ objectPosition: img.objectPosition }}
      />
    </div>
  );
}
