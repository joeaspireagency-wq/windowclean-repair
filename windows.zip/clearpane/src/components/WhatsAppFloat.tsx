import { siteConfig } from "@/site.config";

/** Tablet/laptop/desktop (768px and up): floating WhatsApp button, bottom-right, with a "Contact us" label beside it. */
export function WhatsAppFloat() {
  const { whatsappHref, whatsappLabel } = siteConfig.contact;
  return (
    <a
      href={whatsappHref}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={`${whatsappLabel} on WhatsApp`}
      className="group fixed bottom-6 right-6 z-40 hidden items-center gap-3 md:flex"
    >
      <span className="rounded-full bg-white px-4 py-2 text-base font-medium text-charcoal shadow-[0_6px_20px_-6px_rgba(0,0,0,0.35)]">
        {whatsappLabel}
      </span>
      <span className="grid h-14 w-14 place-items-center rounded-full bg-[#25D366] text-white shadow-[0_8px_24px_-6px_rgba(0,0,0,0.45)] transition-transform duration-200 group-hover:scale-105 group-focus-visible:scale-105 motion-reduce:transition-none">
        <svg viewBox="0 0 32 32" className="h-8 w-8" fill="currentColor" aria-hidden="true">
          <path d="M16.04 4C9.4 4 4 9.38 4 16.01c0 2.12.55 4.19 1.6 6.01L4 28l6.1-1.57a12 12 0 0 0 5.94 1.52h.01C22.68 27.95 28 22.57 28 15.94 28 9.37 22.67 4 16.04 4Zm0 21.9h-.01a9.95 9.95 0 0 1-5.07-1.39l-.36-.22-3.62.93.97-3.52-.24-.36a9.9 9.9 0 0 1-1.52-5.3c0-5.48 4.47-9.94 9.96-9.94 2.66 0 5.15 1.03 7.03 2.91a9.86 9.86 0 0 1 2.91 7.03c0 5.48-4.47 9.86-9.05 9.86Zm5.46-7.43c-.3-.15-1.77-.87-2.04-.97-.27-.1-.47-.15-.67.15-.2.3-.77.97-.94 1.17-.17.2-.35.22-.65.07-.3-.15-1.26-.46-2.4-1.48-.89-.79-1.49-1.77-1.66-2.07-.17-.3-.02-.46.13-.61.14-.13.3-.35.45-.52.15-.17.2-.3.3-.5.1-.2.05-.37-.02-.52-.08-.15-.67-1.62-.92-2.22-.24-.58-.49-.5-.67-.51h-.57c-.2 0-.52.07-.8.37-.27.3-1.04 1.02-1.04 2.49s1.07 2.89 1.22 3.09c.15.2 2.1 3.2 5.08 4.49.71.31 1.26.49 1.7.63.71.23 1.36.2 1.88.12.57-.09 1.77-.72 2.02-1.42.25-.7.25-1.29.17-1.42-.07-.12-.27-.2-.57-.35Z" />
        </svg>
      </span>
    </a>
  );
}
