"use client";

import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import dynamic from "next/dynamic";
import type { ProblemId, UrgencyId } from "@/lib/quote/schema";

// The drawer (form + Zod schemas) loads after first paint, off the critical path.
// `npm run build:portable` sets NEXT_PUBLIC_EAGER_DRAWER=1 so everything is in the
// initial bundle and the page can be inlined into ONE html file that opens from disk.
const EAGER = process.env.NEXT_PUBLIC_EAGER_DRAWER === "1";
const loadDrawer = () => import("./QuoteDrawer").then((m) => m.QuoteDrawer);
const QuoteDrawer = EAGER
  ? // eslint-disable-next-line @typescript-eslint/no-require-imports
    (require("./QuoteDrawer") as typeof import("./QuoteDrawer")).QuoteDrawer
  : dynamic(loadDrawer, { ssr: false });

export type QuotePreset = {
  /** Step to open at (default 1). The hero opens at step 2 with the postcode prefilled. */
  step?: 1 | 2 | 3;
  postcode?: string;
  problem?: ProblemId;
  urgency?: UrgencyId;
};

type QuoteContextValue = {
  isOpen: boolean;
  openQuote: (preset?: QuotePreset) => void;
};

const QuoteContext = createContext<QuoteContextValue | null>(null);

export function useQuote(): QuoteContextValue {
  const ctx = useContext(QuoteContext);
  if (!ctx) throw new Error("useQuote must be used inside <QuoteProvider>");
  return ctx;
}

/** Every CTA, problem card and price card opens the SAME drawer through this context. */
export function QuoteProvider({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  const [preset, setPreset] = useState<QuotePreset>({});
  const [nonce, setNonce] = useState(0);

  const openQuote = useCallback((p: QuotePreset = {}) => {
    setPreset(p);
    setNonce((n) => n + 1);
    setOpen(true);
  }, []);
  const close = useCallback(() => setOpen(false), []);

  // Warm the drawer chunk once the browser is idle so the first open is instant.
  useEffect(() => {
    if (EAGER) return;
    const idle = window.requestIdleCallback ?? ((cb: () => void) => window.setTimeout(cb, 1500));
    const id = idle(() => void loadDrawer());
    return () => {
      if (window.cancelIdleCallback) window.cancelIdleCallback(id as number);
    };
  }, []);

  const value = useMemo(() => ({ isOpen: open, openQuote }), [open, openQuote]);

  return (
    <QuoteContext.Provider value={value}>
      {children}
      <QuoteDrawer open={open} preset={preset} nonce={nonce} onClose={close} />
    </QuoteContext.Provider>
  );
}
