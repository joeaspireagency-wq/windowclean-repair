"use client";

import { useEffect, useId, useRef, useState, type FormEvent } from "react";
import { AlertTriangle, ArrowLeft, ArrowRight, Camera, Check, LoaderCircle, Phone, X } from "lucide-react";
import { siteConfig } from "@/site.config";
import { ProblemIcon } from "@/components/ui/icons";
import { createDemoAdapter, demoAdapter } from "@/lib/quote/adapter";
import {
  stepSchemas,
  type ProblemId,
  type QuoteReceipt,
  type UrgencyId,
} from "@/lib/quote/schema";
import { submitQuote, type QuoteError } from "@/lib/quote/submit";
import type { QuotePreset } from "./QuoteProvider";

type Values = {
  postcode: string;
  problem: ProblemId | "";
  urgency: UrgencyId | "";
  name: string;
  phone: string;
};
type Field = keyof Values;
type Errors = Partial<Record<Field, string>>;
type Status = "idle" | "submitting" | "success" | "error";

const STEP_FIELDS: Record<1 | 2 | 3, Field[]> = {
  1: ["postcode"],
  2: ["problem", "urgency"],
  3: ["name", "phone"],
};

const STEP_TITLES: Record<1 | 2 | 3, string> = {
  1: "Where's the job?",
  2: "What's the problem?",
  3: "Where should we ring?",
};

function stepErrors(step: 1 | 2 | 3, values: Values): Errors {
  const slice = Object.fromEntries(STEP_FIELDS[step].map((f) => [f, values[f]]));
  const parsed = stepSchemas[step].safeParse(slice);
  if (parsed.success) return {};
  const errors: Errors = {};
  for (const issue of parsed.error.issues) {
    const key = issue.path[0] as Field;
    errors[key] ??= issue.message;
  }
  return errors;
}

export function QuoteForm({ preset, onDone }: { preset: QuotePreset; onDone: () => void }) {
  const [step, setStep] = useState<1 | 2 | 3>(preset.step ?? 1);
  const [values, setValues] = useState<Values>({
    postcode: preset.postcode ?? "",
    problem: preset.problem ?? "",
    urgency: preset.urgency ?? "",
    name: "",
    phone: "",
  });
  const [errors, setErrors] = useState<Errors>({});
  const [errorTick, setErrorTick] = useState(0);
  const [status, setStatus] = useState<Status>("idle");
  const [submitError, setSubmitError] = useState<QuoteError | null>(null);
  const [receipt, setReceipt] = useState<QuoteReceipt | null>(null);
  const [photoName, setPhotoName] = useState<string>("");
  const attempts = useRef(0);
  const formRef = useRef<HTMLFormElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const uid = useId();

  const set = <K extends Field>(key: K, value: Values[K]) => {
    setValues((v) => ({ ...v, [key]: value }));
    setErrors((e) => (e[key] ? { ...e, [key]: undefined } : e));
  };

  // Move focus to the first error after validation.
  useEffect(() => {
    if (!errorTick) return;
    const el = formRef.current?.querySelector<HTMLElement>(
      'input[aria-invalid="true"], fieldset[data-invalid="true"] input',
    );
    el?.focus();
  }, [errorTick]);

  // Move focus to the step heading when the step (or result) changes.
  const mounted = useRef(false);
  useEffect(() => {
    if (!mounted.current) {
      mounted.current = true;
      // First paint: focus the main field on desktop only (avoids opening the keyboard on phones).
      return;
    }
    headingRef.current?.focus();
  }, [step, status]);

  const validateField = (field: Field) => {
    const errs = stepErrors(step, values);
    setErrors((e) => ({ ...e, [field]: errs[field] }));
  };

  const next = () => {
    const errs = stepErrors(step, values);
    if (Object.keys(errs).length) {
      setErrors(errs);
      setErrorTick((t) => t + 1);
      return;
    }
    setErrors({});
    setStep((s) => (s < 3 ? ((s + 1) as 2 | 3) : s));
  };

  const back = () => {
    setErrors({});
    setStep((s) => (s > 1 ? ((s - 1) as 1 | 2) : s));
  };

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    if (step < 3) return next();
    if (status === "submitting") return;

    const errs = stepErrors(3, values);
    if (Object.keys(errs).length) {
      setErrors(errs);
      setErrorTick((t) => t + 1);
      return;
    }

    setStatus("submitting");
    setSubmitError(null);

    // `?simulate=error` makes the FIRST attempt fail so the error + retry UI can be demonstrated.
    const simulate =
      attempts.current === 0 && new URLSearchParams(window.location.search).get("simulate") === "error";
    attempts.current += 1;

    const result = await submitQuote(values, simulate ? createDemoAdapter({ fail: "network" }) : demoAdapter);
    if (result.ok) {
      setReceipt(result.receipt);
      setStatus("success");
    } else {
      setSubmitError(result.error);
      setStatus("error");
      if (result.error.kind === "validation" && result.error.fieldErrors) {
        setErrors(result.error.fieldErrors as Errors);
        setErrorTick((t) => t + 1);
      }
    }
  };

  /* ---------------- success ---------------- */
  if (status === "success" && receipt) {
    const first = values.name.trim().split(/\s+/)[0] ?? values.name;
    const emergency = receipt.urgency === "emergency";
    return (
      <div className="text-center" aria-live="polite">
        <div className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-navy text-offwhite">
          <Check className="h-8 w-8" aria-hidden />
        </div>
        <h2 ref={headingRef} tabIndex={-1} className="mt-5 text-2xl text-navy outline-none sm:text-3xl">
          Thanks {first}
        </h2>
        <p className="mt-3 text-lg text-charcoal">
          {emergency
            ? `Thanks ${first}, Stuart's team will ring you within 30 minutes (Mon-Sat, opening hours).`
            : `Thanks ${first}, Stuart's team will ring you within 2 hours (Mon-Sat).`}
        </p>
        <p className="mt-4 rounded-xl bg-ice px-4 py-3 text-sm text-navy">
          This was a demonstration, so nothing was sent. Demo reference: <strong>{receipt.reference}</strong>
        </p>
        <button
          type="button"
          onClick={onDone}
          className="mt-6 inline-flex min-h-12 items-center justify-center rounded-full bg-navy px-8 font-heading font-bold text-offwhite transition-colors hover:bg-navy-mid"
        >
          Close
        </button>
      </div>
    );
  }

  const submitting = status === "submitting";

  return (
    <form ref={formRef} onSubmit={submit} noValidate aria-describedby={`${uid}-status`}>
      {/* Progress */}
      <div className="mb-6">
        <div className="mb-2 flex items-baseline justify-between text-sm font-medium text-muted">
          <span>
            Step {step} of 3
          </span>
          <span>{["Postcode", "The problem", "Your details"][step - 1]}</span>
        </div>
        <div
          role="progressbar"
          aria-label="Quote form progress"
          aria-valuemin={1}
          aria-valuemax={3}
          aria-valuenow={step}
          aria-valuetext={`Step ${step} of 3`}
          className="h-2 overflow-hidden rounded-full bg-pane"
        >
          <div className="h-full rounded-full bg-navy transition-[width] duration-300" style={{ width: `${(step / 3) * 100}%` }} />
        </div>
      </div>

      <h2 ref={headingRef} tabIndex={-1} className="mb-5 text-2xl text-navy outline-none sm:text-[1.75rem]">
        {STEP_TITLES[step]}
      </h2>

      <p id={`${uid}-status`} role="status" aria-live="polite" className="sr-only-live">
        {submitting ? "Sending your request" : ""}
      </p>

      {/* STEP 1 */}
      {step === 1 && (
        <div>
          <Label htmlFor="qf-postcode">Your postcode</Label>
          <input
            id="qf-postcode"
            name="postcode"
            type="text"
            inputMode="text"
            autoComplete="postal-code"
            autoCapitalize="characters"
            placeholder={siteConfig.hero.postcodePlaceholder}
            value={values.postcode}
            onChange={(e) => set("postcode", e.target.value.toUpperCase())}
            onBlur={() => values.postcode && validateField("postcode")}
            aria-invalid={errors.postcode ? true : undefined}
            aria-describedby={`${uid}-postcode-help${errors.postcode ? ` ${uid}-postcode-err` : ""}`}
            className={inputClass(!!errors.postcode)}
          />
          <FieldError id={`${uid}-postcode-err`} message={errors.postcode} />
          <p id={`${uid}-postcode-help`} className="mt-2 text-sm text-muted">
            We cover {siteConfig.business.areaServed}.
          </p>
        </div>
      )}

      {/* STEP 2 */}
      {step === 2 && (
        <div className="space-y-7">
          <fieldset data-invalid={errors.problem ? true : undefined} aria-describedby={errors.problem ? `${uid}-problem-err` : undefined}>
            <legend className="mb-3 text-base font-semibold text-charcoal">What&apos;s wrong with your windows?</legend>
            <div className="grid grid-cols-2 gap-3">
              {siteConfig.problems.items.map((item, i) => (
                <label
                  key={item.id}
                  className={`relative cursor-pointer ${i === siteConfig.problems.items.length - 1 ? "col-span-2" : ""}`}
                >
                  <input
                    type="radio"
                    name="problem"
                    value={item.id}
                    checked={values.problem === item.id}
                    onChange={() => set("problem", item.id)}
                    className="peer sr-only"
                  />
                  <span className="card flex min-h-[7rem] flex-col items-center justify-center gap-2 px-3 py-4 text-center transition peer-checked:border-navy peer-checked:bg-ice peer-checked:shadow-[0_0_0_2px_var(--color-navy)] peer-focus-visible:outline peer-focus-visible:outline-[3px] peer-focus-visible:outline-offset-2 peer-focus-visible:outline-navy hover:border-navy/50">
                    <ProblemIcon id={item.id} className="h-9 w-9 text-navy" />
                    <span className="font-heading text-base font-semibold leading-tight text-navy">{item.label}</span>
                  </span>
                  <span className="pointer-events-none absolute right-2 top-2 hidden h-6 w-6 place-items-center rounded-full bg-navy text-offwhite peer-checked:grid">
                    <Check className="h-4 w-4" aria-hidden />
                  </span>
                </label>
              ))}
            </div>
            <FieldError id={`${uid}-problem-err`} message={errors.problem} />
          </fieldset>

          <fieldset data-invalid={errors.urgency ? true : undefined} aria-describedby={errors.urgency ? `${uid}-urgency-err` : undefined}>
            <legend className="mb-3 text-base font-semibold text-charcoal">How urgent is it?</legend>
            <div className="grid gap-3">
              {siteConfig.urgency.map((u) => (
                <label key={u.id} className="relative cursor-pointer">
                  <input
                    type="radio"
                    name="urgency"
                    value={u.id}
                    checked={values.urgency === u.id}
                    onChange={() => set("urgency", u.id)}
                    className="peer sr-only"
                  />
                  <span className="card flex min-h-12 items-center gap-3 px-4 py-3 font-heading text-base font-semibold text-navy transition peer-checked:border-navy peer-checked:bg-ice peer-checked:shadow-[0_0_0_2px_var(--color-navy)] peer-focus-visible:outline peer-focus-visible:outline-[3px] peer-focus-visible:outline-offset-2 peer-focus-visible:outline-navy hover:border-navy/50">
                    <span
                      aria-hidden
                      className={`grid h-5 w-5 shrink-0 place-items-center rounded-full border-2 ${values.urgency === u.id ? "border-navy bg-navy" : "border-navy/40 bg-white"}`}
                    >
                      {values.urgency === u.id && <span className="h-2 w-2 rounded-full bg-offwhite" />}
                    </span>
                    {u.label}
                  </span>
                </label>
              ))}
            </div>
            <FieldError id={`${uid}-urgency-err`} message={errors.urgency} />
          </fieldset>

          <div aria-live="polite">
            {values.urgency === "emergency" && (
              <div role="note" className="flex gap-3 rounded-xl border border-navy/25 bg-ice p-4 text-navy">
                <Phone className="mt-0.5 h-5 w-5 shrink-0" aria-hidden />
                <p className="text-base font-medium">{siteConfig.emergencyNote}</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* STEP 3 */}
      {step === 3 && (
        <div className="space-y-5">
          <div>
            <Label htmlFor="qf-name">Your name</Label>
            <input
              id="qf-name"
              name="name"
              type="text"
              autoComplete="name"
              value={values.name}
              onChange={(e) => set("name", e.target.value)}
              onBlur={() => values.name && validateField("name")}
              aria-invalid={errors.name ? true : undefined}
              aria-describedby={errors.name ? `${uid}-name-err` : undefined}
              className={inputClass(!!errors.name)}
            />
            <FieldError id={`${uid}-name-err`} message={errors.name} />
          </div>
          <div>
            <Label htmlFor="qf-phone">Phone number</Label>
            <input
              id="qf-phone"
              name="phone"
              type="tel"
              inputMode="tel"
              autoComplete="tel"
              placeholder="07700 900142"
              value={values.phone}
              onChange={(e) => set("phone", e.target.value)}
              onBlur={() => values.phone && validateField("phone")}
              aria-invalid={errors.phone ? true : undefined}
              aria-describedby={errors.phone ? `${uid}-phone-err` : undefined}
              className={inputClass(!!errors.phone)}
            />
            <FieldError id={`${uid}-phone-err`} message={errors.phone} />
          </div>
          <div>
            <span className="mb-1.5 block text-base font-semibold text-charcoal">
              Photo of the problem <span className="font-normal text-muted">(optional)</span>
            </span>
            <div className="flex flex-wrap items-center gap-3">
              <label className="inline-flex min-h-12 cursor-pointer items-center gap-2 rounded-full border-2 border-navy bg-white px-5 font-heading font-semibold text-navy transition-colors hover:bg-ice has-[:focus-visible]:outline has-[:focus-visible]:outline-[3px] has-[:focus-visible]:outline-offset-2 has-[:focus-visible]:outline-navy">
                <Camera className="h-5 w-5" aria-hidden />
                {photoName ? "Change photo" : "Add a photo"}
                {/* UI only: the file is never read, uploaded or stored. */}
                <input
                  type="file"
                  accept="image/*"
                  className="sr-only"
                  onChange={(e) => setPhotoName(e.target.files?.[0]?.name ?? "")}
                />
              </label>
              {photoName && (
                <span className="inline-flex max-w-full items-center gap-2 rounded-full bg-ice px-3 py-2 text-sm text-navy">
                  <span className="truncate">{photoName}</span>
                  <button
                    type="button"
                    onClick={() => setPhotoName("")}
                    aria-label="Remove photo"
                    className="grid h-6 w-6 place-items-center rounded-full hover:bg-pane"
                  >
                    <X className="h-4 w-4" aria-hidden />
                  </button>
                </span>
              )}
            </div>
            <p className="mt-2 text-sm text-muted">A photo means a faster fixed price.</p>
          </div>

          {status === "error" && submitError && (
            <div role="alert" className="rounded-xl border border-red-300 bg-red-50 p-4 text-charcoal">
              <div className="flex gap-3">
                <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-red-700" aria-hidden />
                <div>
                  <p className="font-semibold text-red-900">{submitError.message}</p>
                  <p className="mt-1 text-sm">
                    Your details are still here. You can try again, or ring us on{" "}
                    <a href={siteConfig.contact.phoneHref} className="font-semibold text-navy underline underline-offset-2">
                      {siteConfig.contact.phone}
                    </a>
                    .
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Actions */}
      <div className="mt-8 flex flex-col-reverse gap-3 sm:flex-row sm:items-center">
        {step > 1 && (
          <button
            type="button"
            onClick={back}
            disabled={submitting}
            className="inline-flex min-h-12 items-center justify-center gap-2 rounded-full border-2 border-navy bg-white px-6 font-heading font-semibold text-navy transition-colors hover:bg-ice disabled:opacity-60"
          >
            <ArrowLeft className="h-5 w-5" aria-hidden />
            Back
          </button>
        )}
        {step < 3 ? (
          <button
            type="button"
            onClick={next}
            className="inline-flex min-h-12 flex-1 items-center justify-center gap-2 rounded-full bg-navy px-8 font-heading font-bold text-offwhite transition-colors hover:bg-navy-mid"
          >
            Next
            <ArrowRight className="h-5 w-5" aria-hidden />
          </button>
        ) : (
          <button type="submit" className="cta flex-1" data-size="lg" disabled={submitting}>
            {submitting ? (
              <>
                <LoaderCircle className="spinner h-5 w-5" aria-hidden />
                Sending...
              </>
            ) : status === "error" ? (
              "Try again"
            ) : (
              siteConfig.ctaLabel
            )}
          </button>
        )}
      </div>
      {step === 3 && <p className="mt-3 text-center text-sm text-muted">{siteConfig.ctaMicrocopy}</p>}
    </form>
  );
}

/* ---------- small helpers ---------- */
function Label({ htmlFor, children }: { htmlFor: string; children: React.ReactNode }) {
  return (
    <label htmlFor={htmlFor} className="mb-1.5 block text-base font-semibold text-charcoal">
      {children}
    </label>
  );
}

function inputClass(invalid: boolean) {
  return `block min-h-14 w-full rounded-xl border-2 bg-white px-4 text-lg text-charcoal placeholder:text-muted/70 transition-colors focus:border-navy ${
    invalid ? "border-red-600" : "border-pane"
  }`;
}

function FieldError({ id, message }: { id: string; message?: string }) {
  if (!message) return null;
  return (
    <p id={id} className="mt-2 flex items-start gap-2 text-sm font-medium text-red-800">
      <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
      {message}
    </p>
  );
}
