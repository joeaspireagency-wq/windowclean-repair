"use client";

import { useEffect, useRef } from "react";
import { X } from "lucide-react";
import { siteConfig } from "@/site.config";
import { QuoteForm } from "./QuoteForm";
import type { QuotePreset } from "./QuoteProvider";

type Props = {
  open: boolean;
  preset: QuotePreset;
  nonce: number;
  onClose: () => void;
};

/**
 * Native <dialog> + showModal(): focus trap, Esc to close and focus return
 * come from the browser. Bottom sheet on mobile, right-hand panel on desktop.
 */
export function QuoteDrawer({ open, preset, nonce, onClose }: Props) {
  const ref = useRef<HTMLDialogElement>(null);

  useEffect(() => {
    const dialog = ref.current;
    if (!dialog) return;
    if (open && !dialog.open) dialog.showModal();
    if (!open && dialog.open) dialog.close();
  }, [open]);

  return (
    <dialog
      ref={ref}
      className="drawer"
      aria-labelledby="quote-title"
      onClose={onClose}
      onClick={(e) => {
        // A click on the backdrop targets the dialog element itself.
        if (e.target === e.currentTarget) ref.current?.close();
      }}
    >
      <div className="drawer-header flex shrink-0 items-center justify-between gap-4 px-5 py-4 sm:px-6">
        <div>
          <p id="quote-title" className="font-heading text-lg font-bold text-navy">
            {siteConfig.ctaLabel}
          </p>
          <p className="text-sm text-muted">Stuart&apos;s team, {siteConfig.business.location}</p>
        </div>
        <button
          type="button"
          onClick={() => ref.current?.close()}
          aria-label="Close quote form"
          className="grid h-12 w-12 shrink-0 place-items-center rounded-full border border-navy/30 bg-white text-navy transition-colors hover:bg-ice"
        >
          <X className="h-5 w-5" aria-hidden />
        </button>
      </div>

      <div className="min-h-0 flex-1 overflow-y-auto overscroll-contain px-5 py-6 sm:px-6">
        {open && <QuoteForm key={nonce} preset={preset} onDone={() => ref.current?.close()} />}
      </div>
    </dialog>
  );
}
