"use client";

import { useEffect, useRef, useState } from "react";
import { Menu, Phone, X } from "lucide-react";
import { siteConfig } from "@/site.config";
import { Logo } from "@/components/Logo";

export function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const sentinel = useRef<HTMLDivElement>(null);
  const menuButton = useRef<HTMLButtonElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  // "Scrolled" state via IntersectionObserver (no scroll listener).
  useEffect(() => {
    const el = sentinel.current;
    if (!el) return;
    const io = new IntersectionObserver(([entry]) => setScrolled(!!entry && !entry.isIntersecting));
    io.observe(el);
    return () => io.disconnect();
  }, []);

  // Esc closes the menu and returns focus to the button.
  useEffect(() => {
    if (!menuOpen) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setMenuOpen(false);
        menuButton.current?.focus();
      }
    };
    const onPointer = (e: PointerEvent) => {
      const t = e.target as Node;
      if (!menuRef.current?.contains(t) && !menuButton.current?.contains(t)) setMenuOpen(false);
    };
    document.addEventListener("keydown", onKey);
    document.addEventListener("pointerdown", onPointer);
    return () => {
      document.removeEventListener("keydown", onKey);
      document.removeEventListener("pointerdown", onPointer);
    };
  }, [menuOpen]);

  return (
    <>
      <div ref={sentinel} aria-hidden className="pointer-events-none absolute inset-x-0 top-0 h-6" />
      <header className="site-header on-dark sticky top-0 z-30 text-offwhite" data-scrolled={scrolled} style={{ height: "var(--header-h)" }}>
        <div className="mx-auto flex h-full max-w-[1200px] items-center justify-between gap-1.5 px-3 sm:gap-3 sm:px-8">
          <a href="#top" aria-label={`${siteConfig.business.name}, back to top`} className="shrink-0 rounded-md">
            <Logo />
          </a>

          <nav aria-label="Main" className="hidden items-center gap-7 lg:flex">
            {siteConfig.nav.map((item) => (
              <a key={item.href} href={item.href} className="text-[0.9375rem] font-medium text-ice transition-colors hover:text-white">
                {item.label}
              </a>
            ))}
            <a href={siteConfig.contact.phoneHref} className="inline-flex items-center gap-2 whitespace-nowrap text-[0.9375rem] font-semibold text-offwhite hover:text-white">
              <Phone className="h-4 w-4" aria-hidden />
              {siteConfig.contact.phone}
            </a>
          </nav>

          <div className="flex items-center gap-1.5 sm:gap-3">
            <a
              href={siteConfig.contact.phoneHref}
              aria-label={`Call ${siteConfig.contact.phone}`}
              className="grid h-9 w-9 shrink-0 place-items-center rounded-full border border-ice/40 text-offwhite transition-colors hover:bg-white/10 lg:hidden"
            >
              <Phone className="h-[18px] w-[18px]" aria-hidden />
            </a>
            <button
              ref={menuButton}
              type="button"
              className="grid h-9 w-9 place-items-center rounded-full border border-ice/40 sm:h-10 sm:w-10 text-offwhite transition-colors hover:bg-white/10 lg:hidden"
              aria-expanded={menuOpen}
              aria-controls="mobile-menu"
              aria-label={menuOpen ? "Close menu" : "Open menu"}
              onClick={() => setMenuOpen((o) => !o)}
            >
              {menuOpen ? <X className="h-6 w-6" aria-hidden /> : <Menu className="h-6 w-6" aria-hidden />}
            </button>
          </div>
        </div>

        {/* Mobile menu: anchors + phone. The phone icon stays in the bar. */}
        <div
          id="mobile-menu"
          ref={menuRef}
          hidden={!menuOpen}
          className="absolute inset-x-0 top-full bg-navy shadow-[0_24px_40px_-16px_rgba(0,0,0,0.5)] lg:hidden"
        >
          <nav aria-label="Mobile" className="mx-auto flex max-w-[1200px] flex-col px-4 py-3 sm:px-8">
            {siteConfig.nav.map((item) => (
              <a
                key={item.href}
                href={item.href}
                onClick={() => setMenuOpen(false)}
                className="flex min-h-12 items-center rounded-lg px-2 text-lg font-medium text-offwhite hover:bg-white/10"
              >
                {item.label}
              </a>
            ))}
            <a
              href={siteConfig.contact.phoneHref}
              className="mt-1 flex min-h-12 items-center gap-3 rounded-lg px-2 text-lg font-semibold text-offwhite hover:bg-white/10"
            >
              <Phone className="h-5 w-5" aria-hidden />
              {siteConfig.contact.phone}
            </a>
          </nav>
        </div>
      </header>
    </>
  );
}
