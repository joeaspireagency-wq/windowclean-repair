import { siteConfig } from "@/site.config";
import { LogoMark } from "@/components/ui/icons";

/** SVG logo + wordmark (SVG so nothing is preloaded as an image). */
export function Logo({ tone = "dark", showTag = true }: { tone?: "dark" | "light"; showTag?: boolean }) {
  return (
    <span className="inline-flex items-center gap-2 sm:gap-2.5">
      <LogoMark className="h-8 w-8 shrink-0 sm:h-9 sm:w-9" />
      <span className="flex flex-col leading-none">
        <span className={`font-heading text-[1.1rem] font-bold sm:text-[1.3rem] tracking-tight ${tone === "dark" ? "text-offwhite" : "text-navy"}`}>
          {siteConfig.business.shortName}
        </span>
        {showTag && (
          <span className={`mt-1 hidden text-[0.6875rem] font-medium uppercase tracking-[0.12em] sm:block ${tone === "dark" ? "text-ice/80" : "text-muted"}`}>
            Glazing &amp; Window Repair
          </span>
        )}
      </span>
    </span>
  );
}
