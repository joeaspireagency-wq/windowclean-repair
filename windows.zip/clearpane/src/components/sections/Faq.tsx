"use client";

import { useId, useState } from "react";
import { ChevronDown } from "lucide-react";
import { siteConfig } from "@/site.config";
import { Section } from "@/components/ui/Section";

export function Faq() {
  const { faqs } = siteConfig;
  const [open, setOpen] = useState<Set<number>>(new Set([0])); // first item open
  const uid = useId();

  const toggle = (i: number) =>
    setOpen((prev) => {
      const next = new Set(prev);
      if (next.has(i)) next.delete(i);
      else next.add(i);
      return next;
    });

  return (
    <Section id="faq" tone="offwhite" labelledBy="faq-title" className="!py-[1.875rem] sm:!py-[2.25rem]">
      <h2 id="faq-title" className="mb-5 text-center text-[1.5rem] text-navy sm:text-3xl">
        {faqs.headline}
      </h2>

      <div className="mx-auto max-w-3xl space-y-2">
        {faqs.items.map((item, i) => {
          const isOpen = open.has(i);
          const btnId = `${uid}-b${i}`;
          const panelId = `${uid}-p${i}`;
          return (
            <div key={item.q} className="card overflow-hidden">
              <h3 className="!text-base">
                <button
                  id={btnId}
                  type="button"
                  aria-expanded={isOpen}
                  aria-controls={panelId}
                  onClick={() => toggle(i)}
                  className="flex min-h-12 w-full items-center justify-between gap-3 px-4 py-2.5 text-left font-heading text-base font-bold text-navy sm:px-5"
                >
                  {item.q}
                  <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full border-2 border-navy text-navy">
                    <ChevronDown className={`h-4 w-4 transition-transform duration-200 motion-reduce:transition-none ${isOpen ? "rotate-180" : ""}`} aria-hidden />
                  </span>
                </button>
              </h3>
              <div id={panelId} role="region" aria-labelledby={btnId} className="acc-panel" data-open={isOpen} inert={!isOpen}>
                <div>
                  <p className="px-4 pb-4 text-[0.9375rem] text-charcoal sm:px-5">{item.a}</p>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <p className="mt-6 text-center font-heading text-lg font-bold text-navy">{faqs.closing}</p>
    </Section>
  );
}
