"use client";

import { ArrowRight } from "lucide-react";
import { siteConfig } from "@/site.config";
import { useQuote } from "@/components/quote/QuoteProvider";

/** Hero call to action: the single "Get Your Free Quote" button that opens the quote drawer. */
export function HeroForm() {
  const { openQuote } = useQuote();
  return (
    <div className="w-full max-w-xl">
      <button
        type="button"
        onClick={() => openQuote()}
        className="cta"
        data-on="dark"
        data-size="lg"
        aria-haspopup="dialog"
      >
        {siteConfig.ctaLabel}
        <ArrowRight className="h-5 w-5" aria-hidden />
      </button>
      <p className="mt-3 text-sm text-ice/85">{siteConfig.ctaMicrocopy}</p>
    </div>
  );
}
