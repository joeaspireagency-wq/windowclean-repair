import { Check } from "lucide-react";
import { siteConfig } from "@/site.config";
import { Section } from "@/components/ui/Section";

export function HowItWorks() {
  const { how } = siteConfig;
  return (
    <Section id="how-it-works" tone="ice" labelledBy="how-title" className="!py-[1.3125rem] sm:!py-[1.6875rem]">
      <h2 id="how-title" className="mb-4 text-center text-[1.375rem] text-navy sm:text-2xl">
        {how.headline}
      </h2>

      <ol className="relative grid gap-2 sm:gap-3 lg:grid-cols-3">
        {how.steps.map((step, i) => (
          <li key={step.title} className="card relative flex items-start gap-3 p-3 sm:p-4 lg:flex-col">
            <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-navy font-heading text-base font-bold text-offwhite">
              {i + 1}
            </span>
            <div>
              <h3 className="text-base text-navy">{step.title}</h3>
              <p className="mt-0.5 text-sm leading-snug text-muted">{step.text}</p>
            </div>
          </li>
        ))}
      </ol>

      <div className="card mt-3 p-3 sm:p-4">
        <h3 className="text-base text-navy sm:text-lg">{how.includedHeadline}</h3>
        <ul className="mt-2 grid gap-x-6 gap-y-1.5 sm:grid-cols-2 lg:grid-cols-3">
          {how.included.map((item) => (
            <li key={item} className="flex items-start gap-2 text-sm">
              <span className="mt-0.5 grid h-4 w-4 shrink-0 place-items-center rounded-full bg-navy text-offwhite">
                <Check className="h-2.5 w-2.5" strokeWidth={3} aria-hidden />
              </span>
              {item}
            </li>
          ))}
        </ul>
      </div>
    </Section>
  );
}
