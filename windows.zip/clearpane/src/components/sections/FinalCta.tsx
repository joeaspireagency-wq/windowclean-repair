import { siteConfig } from "@/site.config";
import { AmbientShapes } from "@/components/motion/AmbientShapes";
import { CtaButton } from "@/components/ui/CtaButton";

export function FinalCta() {
  const { finalCta } = siteConfig;
  return (
    <section
      id="get-quote"
      aria-labelledby="final-title"
      className="on-dark relative isolate overflow-hidden py-[3.75rem] text-offwhite sm:py-[5.25rem]"
      style={{ backgroundImage: "linear-gradient(180deg, var(--color-navy-mid), var(--color-navy))" }}
    >
      <AmbientShapes set="finalCta" variant="dark" />
      <div className="relative z-10 mx-auto flex max-w-3xl flex-col items-center px-5 text-center sm:px-8">
        <h2 id="final-title" className="text-[2rem] sm:text-5xl">
          {finalCta.headline}
        </h2>
        <p className="mt-4 text-lg text-ice sm:text-xl">{finalCta.subhead}</p>
        <div className="mt-9 flex flex-col items-center">
          <CtaButton on="dark" size="lg" className="sm:!px-12 sm:!py-5 sm:!text-xl" />
        </div>
      </div>
    </section>
  );
}
