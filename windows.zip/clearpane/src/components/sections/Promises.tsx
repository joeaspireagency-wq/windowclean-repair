import { siteConfig } from "@/site.config";
import { AmbientShapes } from "@/components/motion/AmbientShapes";
import { Icon } from "@/components/ui/icons";
import { Section } from "@/components/ui/Section";

export function Promises() {
  const { guarantees } = siteConfig;
  return (
    <Section id="promises" tone="navy" labelledBy="promises-title" className="!py-[0.9375rem] sm:!py-[1.125rem]" shapes={<AmbientShapes set="promises" variant="dark" />}>
      <h2 id="promises-title" className="mb-2.5 text-center text-lg text-offwhite sm:text-xl">
        {guarantees.headline}
      </h2>

      <div className="grid grid-cols-2 gap-1.5 sm:gap-2 lg:grid-cols-4">
        {guarantees.items.map((g) => (
          <article key={g.title} className="card-dark glint p-2.5" data-glint>
            <div className="glint-content">
              <div className="flex items-center gap-2">
                <span className="grid h-6 w-6 shrink-0 place-items-center rounded-md bg-ice text-navy">
                  <Icon name={g.icon} className="h-3 w-3" />
                </span>
                <h3 className="text-[0.8125rem] leading-tight text-offwhite">{g.title}</h3>
              </div>
              <p className="mt-1 text-xs leading-snug text-ice/90">{g.text}</p>
            </div>
          </article>
        ))}
      </div>

    </Section>
  );
}
