"use client";

import { useCallback, useEffect, useRef, useState, type KeyboardEvent } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { siteConfig } from "@/site.config";
import { Section } from "@/components/ui/Section";
import { Stars } from "@/components/ui/icons";

/**
 * CSS scroll-snap carousel: 1 card on mobile, 2 on tablet, 3 on desktop.
 * Native swipe, arrow buttons, dots and Left/Right keys. No auto-advance.
 */
export function Reviews() {
  const { reviews } = siteConfig;
  const total = reviews.items.length;
  const track = useRef<HTMLDivElement>(null);
  const [index, setIndex] = useState(0);
  const [perView, setPerView] = useState(1);

  const measure = useCallback(() => {
    const el = track.current;
    const first = el?.firstElementChild as HTMLElement | null;
    if (!el || !first) return;
    const step = first.getBoundingClientRect().width + parseFloat(getComputedStyle(el).columnGap || "0");
    setPerView(Math.max(1, Math.round(el.clientWidth / step)));
    const max = el.scrollWidth - el.clientWidth;
    const i = max <= 0 ? 0 : Math.round(el.scrollLeft / step);
    setIndex(Math.min(Math.max(i, 0), total - 1));
  }, [total]);

  useEffect(() => {
    measure();
    const el = track.current;
    if (!el) return;
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, [measure]);

  const maxIndex = total - perView;
  const goTo = (i: number) => {
    const el = track.current;
    const card = el?.children[Math.min(Math.max(i, 0), maxIndex)] as HTMLElement | undefined;
    if (!el || !card) return;
    el.scrollTo({ left: card.offsetLeft - el.offsetLeft, behavior: "smooth" });
  };

  const onKey = (e: KeyboardEvent) => {
    if (e.key === "ArrowRight") {
      e.preventDefault();
      goTo(index + 1);
    } else if (e.key === "ArrowLeft") {
      e.preventDefault();
      goTo(index - 1);
    }
  };

  const atStart = index <= 0;
  const atEnd = index >= maxIndex;
  const arrow =
    "grid h-12 w-12 place-items-center rounded-full border-2 border-navy bg-white text-navy transition-colors hover:bg-navy hover:text-offwhite disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:bg-white disabled:hover:text-navy";

  return (
    <Section id="reviews" tone="ice" labelledBy="reviews-title">
      <div className="mb-6 text-center sm:mb-8">
        <h2 id="reviews-title" className="text-[1.75rem] text-navy sm:text-4xl lg:text-[2.5rem]">
          {reviews.headline}
        </h2>
      </div>

      <div role="region" aria-roledescription="carousel" aria-label="Customer reviews">
        <div
          ref={track}
          tabIndex={0}
          onKeyDown={onKey}
          onScroll={measure}
          aria-label="Reviews. Use the left and right arrow keys to move between them."
          className="snap-track -mx-5 flex scroll-px-5 gap-5 overflow-x-auto px-5 pb-4 pt-1 sm:-mx-8 sm:scroll-px-8 sm:px-8 lg:mx-0 lg:scroll-px-0 lg:px-0"
        >
          {reviews.items.map((r, i) => (
            <figure
              key={r.name}
              role="group"
              aria-roledescription="slide"
              aria-label={`${i + 1} of ${total}`}
              className="card flex w-[88%] shrink-0 snap-start flex-col p-6 sm:w-[calc((100%-1.25rem)/2)] lg:w-[calc((100%-2.5rem)/3)] sm:p-7"
            >
              <Stars className="h-5 w-5" />
              <blockquote className="mt-4 flex-1 text-lg leading-relaxed text-charcoal">&ldquo;{r.quote}&rdquo;</blockquote>
              <figcaption className="mt-5">
                <span className="block font-heading text-base font-bold text-navy">{r.name}</span>
                <span className="block text-sm text-muted">
                  {r.town} &middot; {r.job}
                </span>
              </figcaption>
            </figure>
          ))}
        </div>

        <div className="mt-4 flex items-center justify-center gap-4">
          <button type="button" aria-label="Previous review" className={arrow} disabled={atStart} onClick={() => goTo(index - 1)}>
            <ChevronLeft className="h-6 w-6" aria-hidden />
          </button>
          <button type="button" aria-label="Next review" className={arrow} disabled={atEnd} onClick={() => goTo(index + 1)}>
            <ChevronRight className="h-6 w-6" aria-hidden />
          </button>
        </div>
      </div>
    </Section>
  );
}
