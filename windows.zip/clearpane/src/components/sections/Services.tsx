import { siteConfig } from "@/site.config";
import { Icon } from "@/components/ui/icons";
import { Section } from "@/components/ui/Section";

export function Services() {
  const { services } = siteConfig;
  return (
    <Section id="what-we-fix" tone="offwhite" labelledBy="services-title" className="!py-[1.5rem] sm:!py-[1.875rem]">
      <div className="mb-5 text-center">
        <h2 id="services-title" className="text-xl text-navy sm:text-2xl">
          {services.headline}
        </h2>
        <span className="mx-auto mt-2 block h-1 w-10 rounded-full bg-orange" aria-hidden />
      </div>
      <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {services.items.map((s) => {
          const urgent = s.icon === "emergency";
          return (
            <li
              key={s.title}
              className={`group relative flex items-start gap-3.5 overflow-hidden rounded-2xl border p-4 transition duration-200 hover:-translate-y-0.5 hover:shadow-glass-lg motion-reduce:transition-none motion-reduce:hover:transform-none ${
                urgent
                  ? "border-navy-mid bg-gradient-to-br from-navy to-navy-mid text-offwhite shadow-glass"
                  : "border-pane bg-gradient-to-br from-white to-ice shadow-glass"
              }`}
            >
              <span
                className={`relative z-10 grid h-12 w-12 shrink-0 place-items-center rounded-xl shadow-sm ${
                  urgent ? "bg-orange text-charcoal" : "bg-navy text-ice"
                }`}
              >
                <Icon name={s.icon} className="h-6 w-6" />
              </span>
              <div className="relative z-10 min-w-0">
                <h3 className={`text-base leading-tight ${urgent ? "text-offwhite" : "text-navy"}`}>{s.title}</h3>
                <p className={`mt-1 text-sm leading-snug ${urgent ? "text-ice/90" : "text-muted"}`}>{s.text}</p>
              </div>
              <Icon
                name={s.icon}
                className={`pointer-events-none absolute -bottom-5 -right-4 h-24 w-24 rotate-[-12deg] transition-transform duration-300 group-hover:rotate-[-4deg] group-hover:scale-110 motion-reduce:transition-none ${
                  urgent ? "text-white/10" : "text-navy/[0.06]"
                }`}
              />
              <span
                aria-hidden
                className={`absolute inset-x-0 top-0 h-1 ${urgent ? "bg-orange" : "bg-gradient-to-r from-navy-mid via-pane to-transparent"}`}
              />
            </li>
          );
        })}
      </ul>
    </Section>
  );
}
