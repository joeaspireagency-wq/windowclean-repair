import { Check } from "lucide-react";
import { siteConfig } from "@/site.config";
import { getImage } from "@/data/images";
import { AmbientShapes } from "@/components/motion/AmbientShapes";
import { Stars } from "@/components/ui/icons";
import { HeroForm } from "./HeroForm";

export function Hero() {
  const { hero, stats, contact } = siteConfig;
  return (
    <section
      id="hero"
      aria-labelledby="hero-title"
      className="relative isolate overflow-hidden bg-navy text-offwhite on-dark"
      style={{ backgroundImage: "radial-gradient(1100px 520px at 85% 0%, var(--color-navy-mid), transparent 70%)" }}
    >
      {/* Decorative background photo (blur is baked into the file) under a navy wash so the text stays readable. */}
      <div aria-hidden className="absolute inset-0 -z-10">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={getImage("hero-bg").src}
          alt=""
          width={getImage("hero-bg").width}
          height={getImage("hero-bg").height}
          decoding="async"
          fetchPriority="low"
          className="h-full w-full scale-105 object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-navy/90 via-navy/80 to-navy/60" />
        <div className="absolute inset-x-0 bottom-0 h-24 bg-gradient-to-t from-navy/70 to-transparent" />
      </div>
      <AmbientShapes set="hero" variant="dark" />
      <div className="relative z-10 mx-auto w-full max-w-[1200px] px-5 pb-12 pt-10 sm:px-8 sm:pt-14 md:pb-[4.5rem] lg:pt-16">
        <div className="max-w-2xl">
          <h1 id="hero-title" className="text-[2.125rem] leading-[1.1] sm:text-5xl lg:text-[3.125rem]">
            {hero.headline}
          </h1>
          <p className="mt-5 max-w-xl text-lg text-ice sm:text-xl">{hero.subhead}</p>

          <ul className="mt-7 space-y-3">
            {hero.bullets.map((b) => (
              <li key={b} className="flex items-center gap-3 text-base font-medium sm:text-lg">
                <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-ice text-navy">
                  <Check className="h-4 w-4" strokeWidth={3} aria-hidden />
                </span>
                {b}
              </li>
            ))}
          </ul>

          <div className="mt-8">
            <HeroForm />
          </div>

          <div className="mt-8 flex flex-col gap-2 text-[0.9375rem] text-ice">
            <p className="flex flex-wrap items-center gap-x-3 gap-y-1">
              <Stars className="h-5 w-5" />
              <span className="font-semibold text-offwhite">
                {stats.rating} stars from {stats.reviewCount} reviews
              </span>
              <span aria-hidden className="text-ice/50">|</span>
              <span>{hero.teamLine}</span>
            </p>
            <p>
              Emergency? Call{" "}
              <a href={contact.phoneHref} className="font-semibold text-offwhite underline underline-offset-4 decoration-ice/50 hover:decoration-offwhite">
                {contact.phone}
              </a>
            </p>
          </div>
        </div>

      </div>
    </section>
  );
}
