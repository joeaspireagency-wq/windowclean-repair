import { Quote } from "lucide-react";
import { siteConfig } from "@/site.config";
import { Section } from "@/components/ui/Section";
import { CompareSlider } from "./CompareSlider";

export function CaseStudy() {
  const { caseStudy: c } = siteConfig;
  return (
    <Section id="results" tone="offwhite" labelledBy="results-title" className="!py-[1.5rem] sm:!py-[1.875rem]">
      <div className="mb-4 text-center">
        <h2 id="results-title" className="mx-auto max-w-3xl text-xl text-navy sm:text-2xl">
          {c.headline}
        </h2>
      </div>

      <div className="mx-auto max-w-2xl">
        <CompareSlider />
      </div>

      <dl className="mx-auto mt-4 grid max-w-3xl grid-cols-2 gap-2 lg:grid-cols-4">
        {c.stats.map((s) => (
          <div key={s.label} className="card p-3">
            <dt className="text-xs font-semibold uppercase tracking-wide text-navy-mid">{s.label}</dt>
            <dd className="mt-1 font-heading text-sm font-bold leading-snug text-navy">{s.value}</dd>
          </div>
        ))}
      </dl>

      <div className="mx-auto mt-2 grid max-w-3xl gap-2 lg:grid-cols-2">
        <div className="card flex flex-col justify-center bg-ice p-3">
          <p className="text-xs font-semibold uppercase tracking-wide text-navy-mid">{c.comparison.label}</p>
          <p className="font-heading text-2xl font-bold text-navy">{c.comparison.value}</p>
          <p className="text-xs text-muted">{c.comparison.note}</p>
        </div>
        <figure className="card p-3">
          <Quote className="h-5 w-5 text-navy-mid" aria-hidden />
          <blockquote className="mt-1 text-sm font-medium text-charcoal">&ldquo;{c.quote}&rdquo;</blockquote>
          <figcaption className="mt-1.5 text-xs font-semibold text-navy">{c.quoteBy}</figcaption>
        </figure>
      </div>
    </Section>
  );
}
