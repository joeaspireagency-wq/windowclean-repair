"use client";

import { useId, useState } from "react";
import { ChevronsLeftRight } from "lucide-react";
import { getImage } from "@/data/images";
import { siteConfig } from "@/site.config";
import { SiteImage } from "@/components/ui/SiteImage";

/**
 * Before / after comparison. A native <input type="range"> covers the image,
 * so pointer drag, touch and keyboard (arrows, Home, End, PageUp/Down) all work.
 * Both images use the same 16:10 crop.
 */
export function CompareSlider() {
  const [pos, setPos] = useState(50);
  const id = useId();
  const { caseStudy } = siteConfig;
  const before = getImage("before-misted");

  return (
    <div className="relative w-full select-none overflow-hidden rounded-xl border border-pane bg-white shadow-glass-lg" style={{ aspectRatio: before.aspectRatio }}>
      {/* After (bottom layer) */}
      <div className="absolute inset-0">
        <SiteImage id="after-clear" rounded={false} className="!h-full" />
      </div>
      {/* Before (top layer, clipped from the right) */}
      <div className="absolute inset-0" style={{ clipPath: `inset(0 ${100 - pos}% 0 0)` }}>
        <SiteImage id="before-misted" rounded={false} className="!h-full" />
      </div>

      <label htmlFor={id} className="sr-only">
        Drag to compare before and after
      </label>
      <input
        id={id}
        type="range"
        min={0}
        max={100}
        step={1}
        value={pos}
        onChange={(e) => setPos(Number(e.target.value))}
        aria-valuetext={`${pos}% before, ${100 - pos}% after`}
        className="compare-range peer"
      />

      <span className="pointer-events-none absolute left-2 top-2 rounded-full bg-navy px-3 py-1 text-xs font-bold text-offwhite shadow">
        {caseStudy.beforeLabel}
      </span>
      <span className="pointer-events-none absolute right-2 top-2 rounded-full bg-offwhite px-3 py-1 text-xs font-bold text-navy shadow">
        {caseStudy.afterLabel}
      </span>

      {/* Handle (sits after the input so peer-focus-visible can ring it) */}
      <div
        className="pointer-events-none absolute inset-y-0 w-0.5 bg-white shadow-[0_0_0_1px_rgba(11,37,69,0.25)] peer-focus-visible:[&>span]:ring-4 peer-focus-visible:[&>span]:ring-navy peer-focus-visible:[&>span]:ring-offset-2"
        style={{ left: `${pos}%` }}
      >
        <span className="absolute left-1/2 top-1/2 grid h-12 w-12 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full border-2 border-navy bg-offwhite text-navy shadow-lg">
          <ChevronsLeftRight className="h-6 w-6" aria-hidden />
        </span>
      </div>
    </div>
  );
}
