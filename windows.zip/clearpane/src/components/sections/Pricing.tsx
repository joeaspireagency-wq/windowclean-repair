"use client";

import { useState } from "react";
import { siteConfig } from "@/site.config";
import type { SizeId } from "@/lib/config-schema";
import { Section } from "@/components/ui/Section";

const gbp = (n: number) => `£${n.toLocaleString("en-GB")}`;

export function Pricing() {
  const { pricing } = siteConfig;
  const [size, setSize] = useState<SizeId>(pricing.defaultSize);
  const current = pricing.sizes.find((s) => s.id === size);

  return (
    <Section id="pricing" tone="ice" labelledBy="pricing-title" className="!py-[1.875rem] sm:!py-[2.25rem]">
      <div className="mx-auto mb-5 max-w-3xl text-center">
        <h2 id="pricing-title" className="text-[1.5rem] text-navy sm:text-3xl">
          {pricing.headline}
        </h2>
        <p className="mt-2 text-base text-muted">{pricing.intro}</p>
      </div>

      {/* Size selector: native radios in a segmented control (arrow keys work out of the box) */}
      <fieldset className="mx-auto mb-5 max-w-xl">
        <legend className="mb-2 w-full text-center text-sm font-semibold uppercase tracking-[0.12em] text-navy-mid">
          Glass size
        </legend>
        <div className="grid grid-cols-3 gap-1 rounded-full border border-pane bg-white p-1 shadow-glass">
          {pricing.sizes.map((s) => (
            <label key={s.id} className="relative cursor-pointer">
              <input
                type="radio"
                name="glass-size"
                value={s.id}
                checked={size === s.id}
                onChange={() => setSize(s.id)}
                className="peer sr-only"
              />
              <span className="flex min-h-12 flex-col items-center justify-center rounded-full px-2 py-1.5 text-center text-navy transition-colors peer-checked:bg-navy peer-checked:text-offwhite peer-focus-visible:outline peer-focus-visible:outline-[3px] peer-focus-visible:outline-offset-2 peer-focus-visible:outline-navy hover:bg-ice peer-checked:hover:bg-navy">
                <span className="font-heading text-base font-bold leading-tight">{s.label}</span>
                <span className="text-xs leading-tight sm:text-sm">{s.range}</span>
              </span>
            </label>
          ))}
        </div>
      </fieldset>
      <p className="sr-only" aria-live="polite">
        Showing {current?.label.toLowerCase()} glass prices, {current?.range}.
      </p>

      <div className="grid gap-3 sm:grid-cols-2 sm:gap-4 xl:grid-cols-4">
        {pricing.cards.map((card) => {
          const price = card.bySize ? card.bySize[size] : card.flatFrom;
          const highlight = Boolean(card.badge);
          return (
            <article
              key={card.id}
              className={`card relative flex flex-col p-4 sm:p-5 ${highlight ? "!border-2 !border-navy shadow-glass-lg" : ""}`}
            >
              {card.badge && (
                <span className="absolute -top-3.5 left-4 rounded-full bg-orange px-3.5 py-1 text-sm font-bold text-charcoal shadow-sm">
                  {card.badge}
                </span>
              )}
              <h3 className="text-lg text-navy">{card.title}</h3>
              <p className="mt-1 text-[0.9375rem] text-muted">{card.blurb}</p>

              <div className="mt-3">
                <p className="text-sm font-semibold uppercase tracking-wide text-navy-mid">
                  {card.bySize ? "From" : card.note?.split(".")[0]}
                </p>
                <p className="mt-1 flex items-baseline gap-2">
                  <span className="font-heading text-4xl font-bold tracking-tight text-navy">{price ? gbp(price) : ""}</span>
                  {card.unit && <span className="text-base text-muted">{card.unit}</span>}
                </p>
                {!card.bySize && card.note?.includes(".") && (
                  <p className="mt-1 text-sm text-muted">{card.note.split(". ").slice(1).join(". ")}</p>
                )}
                {card.bySize && <p className="mt-1 text-sm text-muted">{current?.label} glass, {current?.range}</p>}
              </div>
            </article>
          );
        })}
      </div>

      <p className="mt-5 text-center text-base font-medium text-navy">{pricing.multiUnitNote}</p>
    </Section>
  );
}
