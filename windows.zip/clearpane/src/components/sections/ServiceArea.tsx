import { MapPin } from "lucide-react";
import { siteConfig } from "@/site.config";

/** Deliberately small: a one-line intro and the six towns we cover. */
export function ServiceArea() {
  const { serviceArea } = siteConfig;
  return (
    <section id="service-area" aria-labelledby="area-title" className="bg-offwhite py-[1.875rem] text-charcoal sm:py-[2.25rem]">
      <div className="mx-auto w-full max-w-[1200px] px-5 text-center sm:px-8">
        <h2 id="area-title" className="text-[1.5rem] text-navy sm:text-3xl">
          {serviceArea.headline}
        </h2>
        <p className="mx-auto mt-2 max-w-xl text-base text-muted">{serviceArea.intro}</p>
        <ul className="mt-5 grid grid-cols-3 gap-2 sm:flex sm:flex-wrap sm:justify-center sm:gap-2.5">
          {serviceArea.towns.map((town) => (
            <li
              key={town}
              className="flex items-center justify-center gap-2 rounded-full border border-navy/15 bg-white px-2 py-2 text-sm font-medium text-charcoal sm:px-4 sm:text-base"
            >
              <MapPin className="hidden h-4 w-4 shrink-0 text-navy-mid sm:block" aria-hidden />
              {town}
            </li>
          ))}
        </ul>
      </div>
    </section>
  );
}
