import { siteConfig } from "@/site.config";
import { AmbientShapes } from "@/components/motion/AmbientShapes";
import { Section } from "@/components/ui/Section";
import { SiteImage } from "@/components/ui/SiteImage";

export function About() {
  const { owner } = siteConfig;
  return (
    <Section id="about" tone="ice" labelledBy="about-title" className="!py-[1.875rem] sm:!py-[2.25rem]" shapes={<AmbientShapes set="about" variant="light" />}>
      <div className="grid items-center gap-6 lg:grid-cols-[minmax(0,15rem)_1fr] lg:gap-10">
        <figure className="mx-auto w-full max-w-none sm:max-w-sm lg:max-w-none">
          <div className="card overflow-hidden p-1.5">
            <SiteImage id="stuart-portrait" />
          </div>
          <figcaption className="mt-2 text-center text-xs text-muted">{owner.portraitCaption}</figcaption>
        </figure>

        <div>
          <p className="mb-1.5 text-xs font-semibold uppercase tracking-[0.14em] text-navy-mid">About Stuart</p>
          <h2 id="about-title" className="text-[1.375rem] text-navy sm:text-[1.75rem]">
            Hello, I&apos;m {owner.firstName}.
          </h2>
          <div className="mt-3 space-y-2 text-[0.9375rem] leading-snug text-charcoal">
            {owner.story.map((p) => (
              <p key={p}>{p}</p>
            ))}
          </div>

          <p className="mt-4 font-heading text-lg font-bold text-navy sm:text-xl">
            &ldquo;{owner.line}&rdquo;
          </p>
          <p className="mt-0.5 text-sm text-muted">
            {owner.name}, {owner.role.toLowerCase()}
          </p>
        </div>
      </div>
    </Section>
  );
}
