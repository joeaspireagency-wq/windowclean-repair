"use client";

import { useEffect } from "react";

/**
 * One tiny client runtime for all decorative motion (no scroll listeners,
 * no parallax, no animation library):
 *  1. IntersectionObserver pauses ambient shapes when their section is off-screen.
 *  2. IntersectionObserver (once) draws line dividers and fires glass glints.
 *  3. A single delegated, rAF-throttled pointermove handler feeds the CTA sheen.
 */
export function MotionRuntime() {
  useEffect(() => {
    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    // 1. Pause drifting shapes off-screen.
    const pauser = new IntersectionObserver(
      (entries) => entries.forEach((e) => e.target.classList.toggle("is-paused", !e.isIntersecting)),
      { rootMargin: "120px 0px" },
    );
    document.querySelectorAll("[data-ambient]").forEach((el) => pauser.observe(el));

    // 2. One-shot reveals.
    const reveal = (threshold: number) =>
      new IntersectionObserver(
        (entries, obs) =>
          entries.forEach((e) => {
            if (!e.isIntersecting) return;
            const el = e.target as HTMLElement;
            if (el.dataset.state) el.dataset.state = "drawn";
            else el.classList.add("is-in");
            obs.unobserve(el);
          }),
        { threshold },
      );
    const lines = reveal(0.6);
    const glints = reveal(0.35);
    if (!reduce) {
      document.querySelectorAll<HTMLElement>("[data-line-divider]").forEach((el) => {
        el.dataset.state = "pending";
        lines.observe(el);
      });
      document.querySelectorAll("[data-glint]").forEach((el) => glints.observe(el));
    }

    // 3. CTA sheen follows the cursor (mouse only).
    let raf = 0;
    const onMove = (ev: PointerEvent) => {
      if (ev.pointerType !== "mouse" || raf) return;
      const btn = (ev.target as Element | null)?.closest?.<HTMLElement>(".cta");
      if (!btn) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
        const r = btn.getBoundingClientRect();
        btn.style.setProperty("--mx", `${ev.clientX - r.left}px`);
        btn.style.setProperty("--my", `${ev.clientY - r.top}px`);
      });
    };
    document.addEventListener("pointermove", onMove, { passive: true });

    return () => {
      pauser.disconnect();
      lines.disconnect();
      glints.disconnect();
      document.removeEventListener("pointermove", onMove);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  return null;
}
