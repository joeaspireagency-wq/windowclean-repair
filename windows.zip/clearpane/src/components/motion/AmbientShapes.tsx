import type { CSSProperties } from "react";
import { siteConfig } from "@/site.config";
import type { ShapeSpec } from "@/lib/config-schema";

type Props = {
  /** Which shape set from site.config.ts to render. */
  set: keyof typeof siteConfig.shapes;
  variant: "dark" | "light";
  density?: "low" | "normal";
};

const RGB_VAR: Record<ShapeSpec["tone"], string> = {
  ice: "var(--rgb-ice)",
  offwhite: "var(--rgb-offwhite)",
  orange: "var(--rgb-orange)",
  navy: "var(--rgb-navy)",
};

function shapeStyle(s: ShapeSpec): CSSProperties {
  return {
    "--x": `${s.x}%`,
    "--y": `${s.y}%`,
    "--size": `${s.size}px`,
    "--o": s.opacity,
    "--rgb": RGB_VAR[s.tone],
    "--dur": `${s.duration}s`,
    "--delay": `${s.delay}s`,
    "--dx": `${s.dx}px`,
    "--dy": `${s.dy}px`,
    "--rot": `${s.rotate ?? 0}deg`,
  } as CSSProperties;
}

/**
 * Decorative drifting shapes behind section content (content must sit at
 * z-10). Pure server component: CSS keyframes only, transform-only motion.
 * `variant` documents the colour family (dark = on navy, light = on ice or
 * off-white); the schema in config-schema.ts enforces the opacity ceilings.
 */
export function AmbientShapes({ set, variant, density = "normal" }: Props) {
  const shapes = siteConfig.shapes[set].filter((_, i) => density === "normal" || i % 3 !== 2);
  return (
    <div className="ambient" data-ambient data-variant={variant} aria-hidden="true">
      {shapes.map((s, i) => (
        <span
          key={i}
          className={`shape shape-${s.kind}`}
          data-mobile-hide={s.hideOnMobile ?? false}
          style={shapeStyle(s)}
        >
          {s.kind === "line" && (
            <svg viewBox="0 0 200 24" preserveAspectRatio="none">
              <path
                d={s.curved ? "M0 18 Q100 -10 200 18" : "M0 12 H200"}
                fill="none"
                stroke="currentColor"
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeDasharray={s.dashed ? "6 8" : undefined}
                vectorEffect="non-scaling-stroke"
              />
            </svg>
          )}
        </span>
      ))}
    </div>
  );
}
