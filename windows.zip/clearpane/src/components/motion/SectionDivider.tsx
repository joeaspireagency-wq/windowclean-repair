import type { CSSProperties } from "react";

export type DividerTone = "navy" | "navy-mid" | "ice" | "offwhite";

type Props = {
  from: DividerTone;
  to: DividerTone;
  variant?: "wave" | "line";
  /** Mirror the wave direction. */
  flip?: boolean;
  /** One of three wave profiles (long gentle, short, deep). */
  profile?: 1 | 2 | 3;
};

const tone = (t: DividerTone) => `var(--color-${t})`;

/** Smooth wave path across 2880 units (two full periods, so -50% loops). */
function wavePath(segment: number, amp: number, base: number, startsUp: boolean): string {
  let d = `M0 ${base}`;
  const n = 2880 / segment;
  for (let i = 0; i < n; i++) {
    const up = (i % 2 === 0) === startsUp;
    const y = base + (up ? -1 : 1) * amp * 1.33;
    d += ` C${i * segment + segment * 0.4} ${y} ${(i + 1) * segment - segment * 0.4} ${y} ${(i + 1) * segment} ${base}`;
  }
  return `${d} V100 H0 Z`;
}

const PROFILES = {
  1: { front: wavePath(720, 20, 62, true), back: wavePath(720, 24, 50, false), speed: 36 },
  2: { front: wavePath(360, 13, 64, false), back: wavePath(360, 15, 52, true), speed: 32 },
  3: { front: wavePath(720, 28, 60, false), back: wavePath(720, 18, 46, true), speed: 44 },
} as const;

export function SectionDivider({ from, to, variant = "wave", flip = false, profile = 1 }: Props) {
  if (variant === "line") {
    const dark = from === "navy" || from === "navy-mid";
    const style = {
      "--from": tone(from),
      "--line": dark ? "rgb(247 250 252 / 0.2)" : "rgb(11 37 69 / 0.2)",
    } as CSSProperties;
    return (
      <div className="line-div" style={style} data-line-divider aria-hidden="true">
        <div className="line-div__rail">
          <span className="line-div__dot" />
        </div>
      </div>
    );
  }

  const p = PROFILES[profile];
  const style = {
    "--from": tone(from),
    "--to": tone(to),
  } as CSSProperties;
  return (
    <div className="divider" style={style} aria-hidden="true">
      <div className="divider-flip" data-flip={flip}>
        <svg
          className="divider-layer"
          data-layer="back"
          style={{ "--dur": `${p.speed * 1.45}s` } as CSSProperties}
          viewBox="0 0 2880 100"
          preserveAspectRatio="none"
          focusable="false"
        >
          <path d={p.back} fill="color-mix(in srgb, var(--to) 38%, var(--from))" />
        </svg>
        <svg
          className="divider-layer"
          data-layer="front"
          style={{ "--dur": `${p.speed}s` } as CSSProperties}
          viewBox="0 0 2880 100"
          preserveAspectRatio="none"
          focusable="false"
        >
          <path d={p.front} fill="var(--to)" />
        </svg>
      </div>
    </div>
  );
}
