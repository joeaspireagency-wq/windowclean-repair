import { Clock, Mail, MapPin, Phone } from "lucide-react";
import { siteConfig } from "@/site.config";
import { Logo } from "@/components/Logo";
import { CtaButton } from "@/components/ui/CtaButton";

/** Footer: 3 columns. On mobile only, the quote button and a small call button are fixed to the bottom of the screen. */
export function Footer() {
  const { business, contact, services, footer, disclaimers } = siteConfig;
  const link = "text-ice hover:text-white underline-offset-4 hover:underline";
  return (
    <footer className="on-dark relative bg-navy text-offwhite">
      <div className="mx-auto max-w-[1200px] px-5 pb-28 pt-10 sm:px-8 md:pb-10 md:pt-14">
        <div className="grid gap-10 sm:grid-cols-2 lg:grid-cols-3 lg:gap-8">
          <div>
            <Logo />
            <p className="mt-4 max-w-xs text-base text-ice/90">{footer.blurb}</p>
          </div>

          <nav aria-label="What we fix">
            <h2 className="text-lg text-offwhite">What we fix</h2>
            <ul className="mt-4 space-y-2.5 text-base">
              {services.items.map((s) => (
                <li key={s.title}>
                  <a href="#what-we-fix" className={link}>
                    {s.title}
                  </a>
                </li>
              ))}
            </ul>
          </nav>

          <div>
            <h2 className="text-lg text-offwhite">Contact</h2>
            <ul className="mt-4 space-y-3 text-base text-ice">
              <li className="flex gap-3">
                <Phone className="mt-1 h-4 w-4 shrink-0" aria-hidden />
                <span>
                  <a href={contact.phoneHref} className={link}>{contact.phone}</a>
                </span>
              </li>
              <li className="flex gap-3">
                <Mail className="mt-1 h-4 w-4 shrink-0" aria-hidden />
                <a href={`mailto:${contact.email}`} className={`${link} text-[0.9375rem] [overflow-wrap:anywhere]`}>{contact.email}</a>
              </li>
              <li className="flex gap-3">
                <MapPin className="mt-1 h-4 w-4 shrink-0" aria-hidden />
                <address className="not-italic">
                  {contact.addressLines.map((l) => (
                    <span key={l} className="block">{l}</span>
                  ))}
                </address>
              </li>
              <li className="flex gap-3">
                <Clock className="mt-1 h-4 w-4 shrink-0" aria-hidden />
                <span>
                  {contact.hours.map((h) => (
                    <span key={h.days} className="block">{h.days}: {h.time}</span>
                  ))}
                  <span className="mt-1 block text-ice/80">Emergency call-outs by arrangement.</span>
                </span>
              </li>
            </ul>
          </div>
        </div>

        <p className="mt-12 max-w-3xl text-sm text-ice/85">{disclaimers.footer}</p>

        <div className="mt-6 flex flex-col gap-3 text-sm text-ice/85 sm:flex-row sm:items-center sm:justify-between">
          <p>&copy; {new Date().getFullYear()} {business.name}. All rights reserved.</p>
          <ul className="flex gap-5">
            {footer.legal.map((l) => (
              <li key={l.label}>
                <a href={l.href} className={link}>{l.label}</a>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Mobile only: fixed quote button along the bottom of the screen. */}
      <div className="fixed inset-x-0 bottom-0 z-30 border-t border-ice/15 bg-navy/95 px-4 pb-[max(0.75rem,env(safe-area-inset-bottom))] pt-3 shadow-[0_-8px_24px_-8px_rgba(0,0,0,0.45)] backdrop-blur md:hidden">
        <div className="mx-auto flex max-w-[1200px] items-center gap-3">
          <CtaButton on="dark" className="min-w-0 flex-1" />
          <a
            href={contact.phoneHref}
            aria-label={`Call ${contact.phone}`}
            className="grid h-11 w-11 shrink-0 place-items-center rounded-full border border-ice/40 text-offwhite transition-colors hover:bg-white/10"
          >
            <Phone className="h-5 w-5" aria-hidden />
          </a>
        </div>
      </div>
    </footer>
  );
}
