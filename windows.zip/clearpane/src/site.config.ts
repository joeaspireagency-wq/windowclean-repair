import type { SiteConfig } from "@/lib/config-schema";

/**
 * ALL site content lives here so the template can be reskinned for another
 * UK trade. The object is type-checked against the Zod schema's inferred type
 * (tsc), and parsed by Zod at build time in src/lib/validate-config.ts, so a bad
 * config fails `next build`. (Zod itself is kept out of the browser bundle.)
 *
 * PLACEHOLDER - replace for real client: every value in this file is fictional.
 */
export const siteConfig: SiteConfig = {
  business: {
    name: "Clearpane Glazing & Window Repair", // PLACEHOLDER - replace for real client
    shortName: "Clearpane",
    location: "Stockport",
    areaServed: "Greater Manchester, East Cheshire and the High Peak",
    yearsTrading: 11,
    teamSize: 4,
  },

  owner: {
    name: "Stuart Hale", // PLACEHOLDER - replace for real client
    firstName: "Stuart",
    age: 46,
    role: "Founder and lead glazier",
    line: "If a repair will do, I'll tell you.",
    portraitCaption: "Stuart Hale, founder",
    story: [
      "I started in a glass fabrication factory, cutting and making the same sealed units I fit today. Twenty years on, I still like the moment a foggy window goes clear.",
      "Eleven years ago I watched a firm quote a customer for brand new windows when all they needed was fresh glass. That's why I started Clearpane. I'd rather fix what you've got, charge you fairly and earn your next call.",
      "There are four of us now: two fitters, a surveyor and an office manager who'll pick up when you ring. My van is stocked with cutting tools and the most common sealed unit sizes, so a lot of jobs are done in one visit.",
    ],
  },

  contact: {
    phone: "+44 7340 843583",
    phoneHref: "tel:+447340843583",
    whatsappHref: "https://wa.me/447340843583",
    whatsappLabel: "Contact us",
    email: "hello@clearpaneglazing.example", // PLACEHOLDER - replace for real client
    addressLines: ["Unit 7, Brinksway Business Park", "Stockport SK4 0AB"], // PLACEHOLDER
    hours: [
      { days: "Mon to Fri", time: "8am to 6pm" },
      { days: "Saturday", time: "8am to 2pm" },
    ],
  },

  ctaLabel: "Get Your Free Quote",
  ctaMicrocopy: "Free, no obligation, no pushy sales.",

  stats: { rating: 4.9, reviewCount: 186, windowsFixed: "5,200+" }, // PLACEHOLDER (fictional)

  nav: [
    { label: "How it works", href: "#how-it-works" },
    { label: "Pricing", href: "#pricing" },
    { label: "Reviews", href: "#reviews" },
    { label: "FAQ", href: "#faq" },
  ],

  hero: {
    headline: "Cracked, misted or broken windows? Fixed fast, at a fixed price.",
    subhead: "Send a photo, get a fixed price within hours. Most repairs are done in one visit.",
    bullets: [
      "Fixed price from a photo",
      "Same-day emergency make-safe",
      "10-year sealed unit guarantee",
    ],
    postcodeLabel: "Your postcode",
    postcodePlaceholder: "e.g. SK4 0AB",
    teamLine: "Stuart's team, Stockport",
  },

  problems: {
    headline: "What's wrong with your windows?",
    items: [
      { id: "misted", label: "Misted or foggy", hint: "Fog between the panes" },
      { id: "cracked", label: "Cracked or broken", hint: "Glass cracked or smashed" },
      { id: "wont-close", label: "Won't close or lock", hint: "Handles, hinges, locks" },
      { id: "draughty", label: "Draughty or noisy", hint: "Cold air or street noise" },
      { id: "unsure", label: "Not sure", hint: "Stuart will tell you" },
    ],
  },

  urgency: [
    { id: "emergency", label: "Emergency today" },
    { id: "this-week", label: "This week" },
    { id: "planning", label: "Just planning" },
  ],
  emergencyNote:
    "If there's a break-in in progress or anyone is in danger, call 999. Otherwise we'll ring you within 30 minutes.",

  services: {
    headline: "What we fix",
    items: [
      { title: "Misted double glazing", text: "Foggy between the panes? We swap just the sealed unit, not the whole window.", icon: "misted" },
      { title: "Broken & cracked glass", text: "Single panes, double glazed units and door glass, cut and fitted fast.", icon: "cracked" },
      { title: "Emergency make-safe", text: "Smashed window? We secure and board up, then replace the glass.", icon: "emergency" },
      { title: "Window repairs", text: "Hinges, handles, locks, seals and trickle vents fixed or replaced.", icon: "repair" },
      { title: "Door & conservatory glass", text: "Patio doors, French doors and conservatory panels.", icon: "door" },
      { title: "Draught & noise fixes", text: "New seals and adjustments to keep the warmth in and the noise out.", icon: "draught" },
    ],
  },

  how: {
    headline: "How it works",
    steps: [
      { title: "Send a photo", text: "Tell us what's wrong and send a quick photo. It takes two minutes." },
      { title: "Get a fixed price within hours", text: "Stuart looks at it and sends your price in writing. No call-out fee." },
      { title: "We fix it, often the same or next day", text: "We bring the glass, fit it, tidy up and check everything works." },
    ],
    includedHeadline: "Included in every job",
    included: [
      "Free quote from a photo",
      "Fixed price in writing",
      "Every shard hoovered up and all waste taken away",
      "A check that the window opens, closes and locks properly",
      "10-year guarantee on replacement sealed units",
      "Fully insured fitters",
    ],
  },

  pricing: {
    headline: "Fixed prices, no guesswork",
    intro: "Pick the size of the glass to see our \"from\" prices. Your exact price is fixed in writing before we start.",
    sizes: [
      { id: "small", label: "Small", range: "up to 0.5m²" },
      { id: "medium", label: "Medium", range: "up to 1m²" },
      { id: "large", label: "Large", range: "over 1m²" },
    ],
    defaultSize: "medium",
    cards: [
      {
        id: "misted-unit",
        title: "Misted unit replacement",
        blurb: "Per unit. We swap the sealed glass unit between the panes and keep your frame.",
        unit: "per unit",
        bySize: { small: 95, medium: 135, large: 195 }, // PLACEHOLDER (fictional prices)
        badge: "Most popular",
        problem: "misted",
      },
      {
        id: "broken-pane",
        title: "Broken pane replacement",
        blurb: "Per pane. Single panes, double glazed units and door glass.",
        unit: "per pane",
        bySize: { small: 85, medium: 120, large: 170 }, // PLACEHOLDER (fictional prices)
        problem: "cracked",
      },
      {
        id: "window-repair",
        title: "Window repair",
        blurb: "Hinge, handle, lock or seal. One flat price, whatever the size.",
        flatFrom: 60, // PLACEHOLDER (fictional price)
        note: "flat from",
        problem: "wont-close",
      },
      {
        id: "emergency",
        title: "Emergency make-safe",
        blurb: "We secure and board up so you're safe tonight.",
        flatFrom: 65, // PLACEHOLDER (fictional price)
        note: "flat from. Replacement glass quoted separately",
        problem: "cracked",
        urgency: "emergency",
      },
    ],
    multiUnitNote: "Fixing more than one thing? Ask about a multi-unit saving when we do it all in one visit.",
  },

  guarantees: {
    headline: "Our promises, in writing",
    items: [
      { title: "Fixed-price promise", text: "The price on your written quote is the price you pay. No extras on the day.", icon: "pound" },
      { title: "Right-fit promise", text: "We measure twice, make it to fit, and check every window opens, closes and locks before we leave.", icon: "ruler" },
      { title: "Safe & tidy promise", text: "Safety glass wherever it's needed, and every shard hoovered up before we go.", icon: "sparkles" },
      { title: "10-year sealed unit guarantee", text: "Every replacement sealed unit comes with a written 10-year guarantee.", icon: "shield" },
    ],
  },

  caseStudy: {
    headline: "Misted windows, clear again",
    beforeLabel: "Before",
    afterLabel: "After",
    stats: [
      { label: "Before", value: "Failed seals, fog between panes" },
      { label: "After", value: "Crystal clear, original frames kept" },
      { label: "Time on site", value: "Half a day, 2 fitters" },
      { label: "Price", value: "£405 fixed for 3 units, as quoted" },
    ],
    comparison: {
      label: "Typical cost of replacing the windows instead",
      value: "£2,400+",
      note: "Estimate; varies by home",
    },
    quote: "I thought I needed all new windows. Stuart swapped three units and saved me thousands.",
    quoteBy: "Gemma, Heaton Moor",
  },

  reviews: {
    headline: "Reviews",
    items: [
      { name: "Gemma L.", town: "Heaton Moor", job: "3 misted units", quote: "Was quoted £2,400 for new windows elsewhere. Stuart swapped three sealed units for £405 and they look brand new." },
      { name: "Ian & Sue M.", town: "Cheadle", job: "Smashed back door glass", quote: "Our back door glass was smashed late on a Sunday. Stuart's team had it secured the next morning and replaced it properly the same day." },
      { name: "Beverley A.", town: "Marple", job: "Window repair", quote: "I'm 70 and live alone, so I was nervous about letting a tradesman in. Stuart rang ahead, explained everything and was lovely." },
      { name: "Rob K.", town: "Stockport", job: "Landlord, four rental flats", quote: "Used Clearpane for four rental flats. Photos for a quote, fixed price, no surprises, and they leave it spotless." },
      { name: "Anita S.", town: "Bramhall", job: "Patio door lock", quote: "Our patio door wouldn't lock and I thought we'd need a new one. Stuart fixed the mechanism in under an hour for £60." },
      { name: "Dean P.", town: "Hazel Grove", job: "Cracked pane", quote: "Sent a photo at 8am, had a price by lunch and the new pane in by 4pm. Couldn't be easier." },
    ],
  },

  faqs: {
    headline: "Questions people ask us",
    items: [
      { q: "Do I really need new windows, or can you just fix them?", a: "Often we can just fix them. Misted windows usually need only a new sealed unit, and loose handles, worn seals and failed locks are quick repairs. If the frame is the real problem, we'll tell you honestly." },
      { q: "I've got a broken window. How quickly can you come?", a: "Tell us it's an emergency in the form and we'll ring you back within 30 minutes during opening hours. We secure the window the same day wherever we can, then replace the glass. If there's a break-in in progress, call 999 first." },
      { q: "Will the new glass match my existing windows?", a: "We match the glass type, thickness and look as closely as possible. If your windows have a special finish, we'll explain the options before we order anything." },
      { q: "Is the price fixed? Any hidden call-out fees?", a: "No hidden fees. After you send a photo or we visit, you get a fixed price in writing. That's what you pay, and you pay when the job's finished, not before." },
      { q: "How long does it take, and will it be messy?", a: "Most sealed unit swaps take under an hour per window. We protect your floors, hoover up every shard and take all the waste away. Someone needs to be in to let us in and check the finished job." },
      { q: "Are you insured, and is the glass safe?", a: "Yes. We're fully insured, we fit safety glass wherever it's needed (such as doors and low-level panes), and every replacement sealed unit has a written 10-year guarantee." },
      { q: "Can I really get a fixed price from just a photo?", a: "For most jobs, yes. If we need to see it in person, we'll say so and visit for free. Once you've been given a fixed price in writing, that's the price." },
    ],
    closing: "Still unsure? Send a photo and Stuart will tell you straight.",
  },

  serviceArea: {
    headline: "Where we work",
    intro: "Based in Stockport, covering Greater Manchester and East Cheshire.",
    towns: ["Stockport", "Cheadle", "Bramhall", "Marple", "Didsbury", "Altrincham"],
  },

  finalCta: {
    headline: "Broken, misted or draughty? Let's get it sorted.",
    subhead: "Send a photo and get a fixed price within hours.",
  },

  footer: {
    blurb: "Stuart Hale started Clearpane 11 years ago to fix windows honestly. If a repair will do, he'll tell you.",
    legal: [
      { label: "Privacy", href: "#" }, // PLACEHOLDER - replace for real client
      { label: "Terms", href: "#" }, // PLACEHOLDER - replace for real client
      { label: "Cookies", href: "#" }, // PLACEHOLDER - replace for real client
    ],
  },

  colours: {
    navy: "#0B2545",
    navyMid: "#163A63",
    ice: "#E8F4FA",
    offwhite: "#F7FAFC",
    pane: "#CFE3EE",
    orange: "#FF7A1A",
    orangeHover: "#E8660A",
    charcoal: "#111827",
    muted: "#4B5563",
  },

  disclaimers: {
    footer:
      "Clearpane Glazing & Window Repair is a fictional business created for demonstration. Reviews, results, prices and contact details are examples only.",
  },

  /**
   * Ambient shapes. x/y are % of the section; dx/dy are drift in px.
   * Every duration is unique. Tweak freely: the schema enforces the opacity
   * ceilings from the motion spec.
   */
  shapes: {
    hero: [
      { kind: "ring", x: 60, y: -10, size: 300, tone: "ice", opacity: 0.14, duration: 31.4, delay: -12, dx: 40, dy: 30 },
      { kind: "disc", x: 84, y: 52, size: 380, tone: "orange", opacity: 0.08, duration: 38.2, delay: -20, dx: -50, dy: -40 },
      { kind: "ring", x: 6, y: 68, size: 140, tone: "offwhite", opacity: 0.12, duration: 24.6, delay: -7, dx: 30, dy: -45, hideOnMobile: true },
      { kind: "line", x: 28, y: 10, size: 240, tone: "ice", opacity: 0.16, duration: 27.3, delay: -16, dx: 50, dy: 24, rotate: 6, dashed: true },
      { kind: "disc", x: -8, y: 28, size: 260, tone: "ice", opacity: 0.1, duration: 42.7, delay: -31, dx: 36, dy: 52, hideOnMobile: true },
      { kind: "line", x: 52, y: 86, size: 180, tone: "offwhite", opacity: 0.12, duration: 21.9, delay: -9, dx: -44, dy: -24, rotate: -7, curved: true },
      { kind: "ring", x: 76, y: 18, size: 90, tone: "ice", opacity: 0.17, duration: 19.8, delay: -5, dx: 28, dy: 60, hideOnMobile: true },
    ],
    promises: [
      { kind: "ring", x: 4, y: 10, size: 260, tone: "ice", opacity: 0.12, duration: 33.1, delay: -14, dx: 44, dy: 36 },
      { kind: "disc", x: 80, y: 60, size: 340, tone: "orange", opacity: 0.07, duration: 25.9, delay: -8, dx: -46, dy: -34 },
      { kind: "line", x: 55, y: 6, size: 220, tone: "offwhite", opacity: 0.11, duration: 40.4, delay: -22, dx: 40, dy: 30, rotate: 5, dashed: true, hideOnMobile: true },
      { kind: "ring", x: 90, y: 4, size: 120, tone: "offwhite", opacity: 0.13, duration: 22.7, delay: -11, dx: -30, dy: 50, hideOnMobile: true },
      { kind: "line", x: 14, y: 90, size: 200, tone: "ice", opacity: 0.15, duration: 29.6, delay: -18, dx: 56, dy: -20, rotate: -6, curved: true },
    ],
    finalCta: [
      { kind: "ring", x: 70, y: -20, size: 320, tone: "ice", opacity: 0.13, duration: 35.8, delay: -15, dx: 38, dy: 44 },
      { kind: "disc", x: 8, y: 40, size: 360, tone: "orange", opacity: 0.09, duration: 20.3, delay: -6, dx: 52, dy: -30 },
      { kind: "line", x: 36, y: 20, size: 250, tone: "offwhite", opacity: 0.12, duration: 43.9, delay: -27, dx: -46, dy: 28, rotate: 7, hideOnMobile: true },
      { kind: "ring", x: 88, y: 66, size: 150, tone: "offwhite", opacity: 0.12, duration: 26.8, delay: -13, dx: -34, dy: -46, hideOnMobile: true },
      { kind: "disc", x: 46, y: 80, size: 220, tone: "ice", opacity: 0.1, duration: 18.7, delay: -4, dx: 28, dy: -56 },
      { kind: "line", x: 64, y: 84, size: 170, tone: "ice", opacity: 0.15, duration: 37.1, delay: -19, dx: 42, dy: -26, rotate: -8, dashed: true, hideOnMobile: true },
    ],
    about: [
      { kind: "ring", x: 92, y: 8, size: 240, tone: "navy", opacity: 0.05, duration: 44.2, delay: -21, dx: -40, dy: 34 },
      { kind: "line", x: 4, y: 70, size: 220, tone: "navy", opacity: 0.06, duration: 30.7, delay: -10, dx: 46, dy: -26, rotate: 6, curved: true },
      { kind: "ring", x: 70, y: 86, size: 110, tone: "navy", opacity: 0.07, duration: 23.5, delay: -17, dx: 32, dy: -50, hideOnMobile: true },
    ],
    repair: [
      { kind: "ring", x: -4, y: 6, size: 280, tone: "navy", opacity: 0.05, duration: 39.3, delay: -24, dx: 42, dy: 38 },
      { kind: "line", x: 78, y: 12, size: 230, tone: "navy", opacity: 0.06, duration: 28.4, delay: -12, dx: -44, dy: 30, rotate: -6, dashed: true, hideOnMobile: true },
      { kind: "ring", x: 88, y: 80, size: 130, tone: "navy", opacity: 0.06, duration: 34.6, delay: -8, dx: -28, dy: -48 },
    ],
  },
};

export const ctaLabel = siteConfig.ctaLabel;
