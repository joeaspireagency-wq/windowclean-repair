import type { NextConfig } from "next";

/**
 * Static export so the prototype can be hosted free (Vercel Hobby, Netlify,
 * GitHub Pages). Static export cannot run the image optimiser, so
 * `images.unoptimized` is set (noted in the README). All images are local
 * SVG/AVIF/JPEG files in /public/images, referenced through src/data/images.ts.
 */
const nextConfig: NextConfig = {
  output: "export",
  trailingSlash: true,
  images: { unoptimized: true },
  reactStrictMode: true,
  // Inline the (small) stylesheet so first paint is not blocked by a CSS request.
  experimental: { inlineCss: true },
};

export default nextConfig;
